//
//  ExpressionManager.cpp
//  Lab_3
//
//  Created by Randy Klabacka on 10/14/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#include <stdio.h>
#include <stack>
#include <string>
#include <iostream>
#include <sstream>
#include <string>

#include "ExpressionManager.h"

using namespace std;

//constructor
ExpressionManager::ExpressionManager(){}

//destructor
ExpressionManager::~ExpressionManager(){}

//is_bal
bool ExpressionManager::isBalanced(string expression){
    stack<string> stack;
    stringstream ss;
    ss << expression;
    string element;
    string stack_element;
    while(ss >> element){ //while(ss.eof = false)
        if(element == "(" || element == "[" || element == "{"){
            stack.push(element);
        }
        else if(element == ")" || element == "]" || element == "}"){
                if(!stack.empty()){
		    stack_element = stack.top();
            	    if(stack_element == "(" && element == ")"){
		      	stack.pop();
        	    }
        	    else if(stack_element == "[" && element == "]"){
        	        stack.pop();
        	    }
        	    else if(stack_element == "{" && element == "}"){
        	        stack.pop();
        	    }
        	    else{
            //cout << "not balanced\n";
        	        return false;
        	    }
		}
		else{
            //cout << "not balanced\n";
			return false;
		}
        }
    }
    if(stack.empty()){
    //cout << "balanced\n";
	return true;
    }
    else{
    //cout << " not balanced\n";
	return false;
    }
}

//postfixToInfix
string ExpressionManager::postfixToInfix(string postfixExpression){
    string return_expression;
    stack<string> stack;
    string element;
    stringstream ss;
    ss << postfixExpression;
    while(ss >> element){
	//cout << "postfixToInfix while loop\n";
        if(is_num(element)){
	    //cout << element + " IS A NUMBER!\n";
            stack.push(element);
        }
        else if(is_oper(element)){
	    //cout << element + " IS AN OPERATOR\n";
            if(!stack.empty()){
                string right_value = stack.top();
		stack.pop();
                if(!stack.empty()){
                string left_value = stack.top();
                stack.pop();
                string new_expression = "( " + left_value + " " + element + " " + right_value + " )";
                //cout << "new_expression: " + new_expression + "\n";
		stack.push(new_expression);
		}
		else{
		    return "invalid";
		}
            }
            else{
                return "invalid";
            }
        }
	else{
	    //cout << element + " IS **NEITHER** NUMBER NOR OPERATOR!\n";
            return "invalid";
	}
    }
    if(!stack.empty()){
	return_expression = stack.top();
	stack.pop();
        if(stack.empty()){
	    return return_expression;
        }
	else{
	    return "invalid";
	}
    }
    else{
	return "invalid";
    }
}

//infixToPostfix
string ExpressionManager::infixToPostfix(string infixExpression){
    stack<string> stack;
    stringstream ss;
    string element;
    if(isBalanced(infixExpression)){
    	if(is_valid_in(infixExpression)){
    		if(check_ratio(infixExpression)){
    			//return "valid expression: time to get to work";
    			return in_to_post(infixExpression);
    		}
    		else{
    			return "invalid";
    		}
    	}
    	else{
    		return "invalid";
    	}
    }
    else{
    	return "invalid";
    }
}

//postfixEvaluate
string ExpressionManager::postfixEvaluate(string postfixExpression){
	string str_new_value;
	stack<string> stack;
	string element;
    stringstream ss;
    ss << postfixExpression;
    if(is_valid_post(postfixExpression)){
        if(postfixExpression.length() == 1){
        	while(ss >> element){
        		if(is_num(element)){
        			return element;
        		}
        		else{
        			return "invalid";
        		}
        	}
        }
        else{
    	while(ss >> element){
            //cout << "postfixEvaluate while loop\n";
            if(is_num(element)){
    	    //cout << element + " IS A NUMBER!\n";
                stack.push(element);
            }
            else if(is_oper(element)){
            	//cout << element + " IS AN OPERATOR\n";
                if(!stack.empty()){
                    string str_right_value = stack.top();
                    int int_right_value = string_to_int(str_right_value);
                    stack.pop();
                    if(!stack.empty()){
                    	string str_left_value = stack.top();
                    	int int_left_value = string_to_int(str_left_value);
                    	stack.pop();
                    	if(element == "+"){
                    		int int_new_value = int_left_value + int_right_value;
                    		str_new_value = int_to_string(int_new_value);
                            //cout << "new value: " + str_left_value + " " + element + " " + str_right_value + " = " + str_new_value + "\n";
                    	}
                    	else if(element == "-"){
                    		int int_new_value = int_left_value - int_right_value;
                    		str_new_value = int_to_string(int_new_value);
                            //cout << "new value: " + str_left_value + " " + element + " " + str_right_value + " = " + str_new_value + "\n";
                    	}
                    	else if(element == "*"){
                    		int int_new_value = int_left_value * int_right_value;
                    		str_new_value = int_to_string(int_new_value);
                            //cout << "new value: " + str_left_value + " " + element + " " + str_right_value + " = " + str_new_value + "\n";
                    	}
                    	else if(element == "/"){
                    		if(int_right_value != 0){
                    			int int_new_value = int_left_value / int_right_value;
                    			str_new_value = int_to_string(int_new_value);
                                //cout << "new value: " + str_left_value + " " + element + " " + str_right_value + " = " + str_new_value + "\n";
                    		}
                    		else{
                    			return "invalid";
                    		}
                    	}
                    	else if(element == "%"){
                    		if(int_right_value != 0){
                    			int int_new_value = int_left_value % int_right_value;
                    			str_new_value = int_to_string(int_new_value);
                                //cout << "new value: " + str_left_value + " " + element + " " + str_right_value + " = " + str_new_value + "\n";
                    		}
                    		else{
                    			return "invalid";
                    		}
                    	}
                    //cout << "pushing: " + str_new_value + "\n";
                    stack.push(str_new_value);
                    }
                }
                else{
                	return "invalid";
                }
            }
            else{
            	return "invalid";
            }
    	}
        }
    }
    else{
    	return "invalid";
    }
    return str_new_value;
}

//is_num
bool ExpressionManager::is_num(string str_in){
    //check first for negative sign
    char neg = str_in[0];
    char num = str_in[1];
    if(neg == '-' && isdigit(num)){
        for(int i = 1; i < str_in.length(); i++){
            if(!isdigit(str_in[i])){
                return false;
            }
        }
    }
    else{
        for(int i = 0; i < str_in.length(); i++){
            if(!isdigit(str_in[i])){
                return false;
            }
        }
    }
    return true;
}

//is_oper
bool ExpressionManager::is_oper(string str_in){
    char oper = str_in[0];
    if(oper == '+' || oper == '-' || oper == '*' || oper == '/' || oper == '%'){
        return true;
    }
    return false;
}

//check_validity_infix
bool ExpressionManager::is_valid_in(string str_in){
	stringstream ss;
	string element;
	ss << str_in;
	while(ss >> element){
		if(!is_num(element) && !is_oper(element) && element != "(" && element != ")"){
			return false;
		}
	}
	return true;
}

//check_validity_postfix
bool ExpressionManager::is_valid_post(string str_in){
	stringstream ss;
	string element;
	ss << str_in;
	while(ss >> element){
		if(!is_num(element) && !is_oper(element)){
			return false;
		}
	}
	return true;
}

//check_ratio
bool ExpressionManager::check_ratio(string str_in){
	int oper_count = 0;
	int num_count = 0;
	stringstream ss;
	string element;
	ss << str_in;
	while(ss >> element){
		if(is_num(element)){
			num_count++;
		}
		else if(is_oper(element)){
			oper_count++;
		}
	}
	if(oper_count != (num_count - 1)){
		return false;
	}
	else{
		return true;
	}
}

//in_to_post
string ExpressionManager::in_to_post(string str_in){
	stringstream ss;
	string element;
	string ex_string;
	stack<string> stack;
	ss << str_in;
	while(ss >> element){
		if(is_num(element)){
			ex_string.append(element + " ");
		}
		else{
			if(stack.empty()){
				stack.push(element);
			}
			else{
				string temp = stack.top();
				if(element == "("){
					stack.push(element);
				}
				else if(element == "*" || element == "/"){
					if(temp == "/" || temp == "*"){
						ex_string.append(temp + " ");
						stack.pop();
						stack.push(element);
					}
					else{
						stack.push(element);
					}
				}
				else if(element == "+" || element == "-"){
					if(temp == "/" || temp == "*" || temp == "+" || temp == "-"){
						ex_string.append(temp + " ");
						stack.pop();
						stack.push(element);
					}
					else{
						stack.push(element);
					}
				}
				else if(element == ")"){
					while(temp != "("){
						ex_string.append(temp + " ");
						stack.pop();
						temp = stack.top();
					}
					stack.pop();
				}
			}
		}
	}
	while(!stack.empty()){
		string temp = stack.top();
		stack.pop();
		if(stack.empty()){
			ex_string.append(temp);
		}
		else{
			ex_string.append(temp + " ");
		}
	}
	return ex_string;
}

//string_to_int
int ExpressionManager::string_to_int(string str_in){
	stringstream ss;
	int new_int;
	ss << str_in;
	ss >> new_int;
	return new_int;
}

string ExpressionManager::int_to_string(int int_in){
	stringstream ss;
	string new_str;
	ss << int_in;
	ss >> new_str;
	return new_str;
}
