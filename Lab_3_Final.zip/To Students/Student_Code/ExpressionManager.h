//
//  ExpressionManager.h
//  Lab_3
//
//  Created by Randy Klabacka on 10/14/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_3__ExpressionManager__
#define __Lab_3__ExpressionManager__

#include <stdio.h>
#include <stack>
#include <string>
#include <iostream>
#include <sstream>


#include "ExpressionManagerInterface.h"

using namespace std;

class ExpressionManager:
public ExpressionManagerInterface{
public:
    
    //constructor
    ExpressionManager();
    //destructor
    ~ExpressionManager();
    //is_bal
    bool isBalanced(string expression);
    
    //postfixToInfix
    string postfixToInfix(string postfixExpression);
    
    //infixToPostfix
    string infixToPostfix(string infixExpression);
    
    //postfixEvaluate
    string postfixEvaluate(string postfixExpression);
    
    //check_if_num
    bool is_num(string str_in);
    
    //check_if_operator
    bool is_oper(string str_in);
    
    //check_if_expression_valid_in
    bool is_valid_in(string str_in);

    //check_if_expression_valid_post
    bool is_valid_post(string str_in);

    //check_if_ratio_is: num_oper = num_num - 1
    bool check_ratio(string str_in);

    //in_to_post
    string in_to_post(string str_in);

    //string_to_int
    int string_to_int(string str_in);

    //int_to_string
    string int_to_string(int int_in);

private:
    string expression;
    
};

#endif /* defined(__Lab_3__ExpressionManager__) */
