//
//  Questions.h
//  Lab_1
//
//  Created by Randy Klabacka on 9/15/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#ifndef Lab_1_Questions_h
#define Lab_1_Questions_h


#endif

//If I do type out virtual functions within the derived class where they are not being used, do I still need to put " = 0" at the end of the signature?
//In the derived class where I will be implementing the virtual function, should I still type out "virtual"?
//Why the parentheses after the constructor?
//Where does the getDamage function go?
//Should takeDamage int value function be truncated?
//How do I include the takeDamage function?  Where do I put it?  How do I construct it with the 'damage' parameter?
//What should be the private data members in the Fighter class?
//Do I need to #include all of the same things in my child classes that I had in my parent class?
//Does the archer class have anything special in it?
//Can I create an overriding constructor?
//Why would I ever return false for archer quickstep?

