//
//  Cleric.cpp
//  Lab_1
//
//  Created by Randy Klabacka on 9/15/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#include "Cleric.h"
//Constructor
Cleric::Cleric(string name_in, string type_in, int max_hp_in, int strength_in, int speed_in, int magic_in):Fighter(name_in, type_in, max_hp_in, strength_in, speed_in, magic_in)
{
    mana = 5 * magic_in;
}

/*
 *	getDamage()
 *
 *	Returns the amount of damage a fighter will deal.
 *	Cleric:
 *	This value is equal to the Cleric's magic.
 */
    int Cleric::getDamage()
    {
        return magic;
    }

/*
 *	reset()
 *	Restores a fighter's current hit points to its maximum hit points.
 *	Cleric:
 *	Also restores a Cleric's current mana to its maximum value (which is 5 times its magic).
 */
    void Cleric::reset()
    {
	//cout << " Cleric reset for " << name;
        current_hp = max_hp;
        mana = 5 * magic;
    };

/*
 *	regenerate()
 *
 *	Increases the fighter's current hit points by an amount equal to one sixth of
 *	the fighter's strength.  This method must increase the fighter's current hit
 *	points by at least one.  Do not allow the current hit points to exceed the
 *	maximum hit points.
 *
 *	Cleric:
 *	Also increases a Cleric's current mana by an amount equal to one fifth of the
 *	Cleric's magic.  This method must increase the Cleric's current mana by at
 *	least one.  Do not allow the current mana to exceed the maximum mana (again, 5 times its magic).
 */
//Function override will be used in the parent class
    void Cleric::regenerate()
    {	
	//cout << " Cleric regen active for " << name << " CurrentHP: " << current_hp << " MaxHP: " << max_hp;
        double hp_increase = strength / 6;
        if(hp_increase >= 1)
        {
            current_hp += hp_increase;
            if(current_hp > max_hp)
            {
                current_hp = max_hp;
            }
	}
        else
        {
            current_hp ++;
            if(current_hp > max_hp)
            {
                current_hp = max_hp;
            }
	}
        double mana_increase = magic / 5;
        if(mana_increase >= 1)
        {
            mana += mana_increase;
            if(mana > (5 * magic))
            {
                mana = (5* magic);
            }
        }
        else
        {
            mana ++;
            if(mana > (5 * magic))
            {
                mana = (5 * magic);
            }
        }
	//cout << " Post Cleric regen: Current_HP: " << current_hp << " Mana: " << mana << endl;
    };

/*
 *	useAbility()
 *
 *	Attempts to perform a special ability based on the type of fighter.  The
 *	fighter will attempt to use this special ability just prior to attacking
 *	every turn.
 *
 *	Cleric: Healing Light
 *	Increases the Cleric's current hit points by an amount equal to one third of its magic.
 *	Can only be used if the Cleric has at least [CLERIC_ABILITY_COST] mana.
 *	Will be used even if the Cleric's current HP is equal to their maximum HP.
 *	Decreases the Cleric's current mana by [CLERIC_ABILITY_COST] when used.
 *	Cleric Note:
 *	This ability, when successful, must increase the Cleric's current hit points
 *	by at least one, unless doing so would given the Cleric more hit points than its maximum hit points.
 *	Do not allow the current hit points to exceed the maximum hit points.
 *
 *	Return true if the ability was used; false otherwise.
 */
    bool Cleric::useAbility()
    {
	//cout << " Healing light for: " << name;
	if(mana >= CLERIC_ABILITY_COST){
        	double healing_light = magic / 3;
		if(healing_light >= 1){
			current_hp += healing_light;	
			mana -= CLERIC_ABILITY_COST;
			if(current_hp > max_hp){
				current_hp = max_hp;
				return true;
			}
			else{
			return true;
			}
		}
		else{
			current_hp ++;
			if(current_hp > max_hp){
			current_hp = max_hp;
			return true;}
			return true;
		}
	}
	else{
		return false;
	}
	
	return false;
    };
