//
//  Fighter.cpp
//  Lab_1
//
//  Created by Randy Klabacka on 9/15/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#include "FighterInterface.h"
#include "Fighter.h"

using namespace std;
//Constructor
Fighter::Fighter(std::string name_in, std::string type_in, int max_hp_in, int strength_in, int speed_in, int magic_in)
{
    type = type_in;
    name = name_in;
    max_hp = max_hp_in;
    current_hp = max_hp_in;
    strength = strength_in;
    speed = speed_in;
    magic = magic_in;
}

//getters
//get_name
std::string Fighter::getName()
{
    return name;
}
//get_max_hp
int Fighter::getMaximumHP()
{
    return max_hp;
}
//getCurrentHP- FIX THIS VALUE!
int Fighter::getCurrentHP()
{
    return current_hp;
}
//get_strength
int Fighter::getStrength()
{
    return strength;
}
//get_speed
int Fighter::getSpeed()
{
    return speed;
}
//get_magic
int Fighter::getMagic()
{
    return magic;
}
/*
 *	takeDamage(int)
 *
 *	Reduces the fighter's current hit points by an amount equal to the given
 *	damage minus one fourth of the fighter's speed.  This method must reduce
 *	the fighter's current hit points by at least one.  It is acceptable for
 *	this method to give the fighter negative current hit points.
 *
 *	Examples:
 *		damage=10, speed=7		=> damage_taken=9
 *		damage=10, speed=9		=> damage_taken=8
 *		damage=10, speed=50		=> damage_taken=1
 */
//Damage value should be truncated, not rounded

void Fighter::takeDamage(int given_damage)
{
	//cout << " takeDamage for " << name << " GIVEN damage: " << given_damage << " Speed: " << speed << " Original HP (current): " << current_hp << " for " << name << " Type: " << type << ".  MaxHP is: " << max_hp << endl;
	int speed_effect = ((.25) * speed);
	int damage = .5 + (given_damage - speed_effect);
	if(damage > 1){
		current_hp -= damage;
	}
	else{
	current_hp -= 1;
	}
	//cout << " New HP(post take damage): " << current_hp << " for " << name << ". MaxHP is: " << max_hp << endl;
};

