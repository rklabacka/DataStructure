//
//  Arena.h
//  Lab_1
//
//  Created by Randy Klabacka on 9/21/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#ifndef ARENA_H_
#define ARENA_H_

#include "ArenaInterface.h"
#include "Fighter.h"
#include "Archer.h"
#include "Robot.h"
#include "Cleric.h"

class Arena:
public ArenaInterface
{
public:
    /*
     *	addFighter(string)
     *
     *	Adds a new fighter to the collection of fighters in the arena. Do not allow
     *	duplicate names.  Reject any string that does not adhere to the format
     *	outlined in the lab specs.
     *
     *	Return true if a new fighter was added; false otherwise.
     */
    bool addFighter(string info);
    /*
     *	removeFighter(string)
     *
     *	Removes the fighter whose name is equal to the given name.  Does nothing if
     *	no fighter is found with the given name.
     *
     *	Return true if a fighter is removed; false otherwise.
     */
    bool removeFighter(string name);
    /*
     *	getFighter(string)
     *
     *	Returns the memory address of a fighter whose name is equal to the given
     *	name.  Returns NULL if no fighter is found with the given name.
     *
     *	Return a memory address if a fighter is found; NULL otherwise.
     */
    FighterInterface* getFighter(string name);
    /*
     *	getSize()
     *
     *	Returns the number of fighters in the arena.
     *
     *	Return a non-negative integer.
     */
    int getSize();
    void print_vector_names();
    
private:
    vector<Fighter*> arena_vector;
    
    
};

#endif /* defined(__Lab_1__Arena__) */
