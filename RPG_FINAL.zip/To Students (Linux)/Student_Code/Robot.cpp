//
//  Robot.cpp
//  Lab_1
//
//  Created by Randy Klabacka on 9/15/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#include <math.h>
#include "Robot.h"
//Constructor
Robot::Robot(string name_in, string type_in, int max_hp_in, int strength_in, int speed_in, int magic_in):Fighter(name_in, type_in, max_hp_in, strength_in, speed_in, magic_in)
{
    max_energy = 2 * magic_in;
    current_energy = max_energy;
    bonus_damage = 0;
}

/*
 *	getDamage()
 *
 *	Returns the amount of damage a fighter will deal.
 *	Robot:
 *	This value is equal to the Robot's strength plus any additional damage added for having just used its special ability.
 */
int Robot::getDamage()
{
    int damage;
    if(bonus_damage > 0){
	damage = bonus_damage + strength;
	return damage;
	bonus_damage = 0;
    }
    else{
	return strength;
    }
};

void Robot::reset(){
	current_hp = max_hp;
	current_energy = max_energy;
};

/*
 *	regenerate()
 *
 *	Increases the fighter's current hit points by an amount equal to one sixth of
 *	the fighter's strength.  This method must increase the fighter's current hit
 *	points by at least one.  Do not allow the current hit points to exceed the
 *	maximum hit points.
 *
 */
//Function override will be used in the parent class
void Robot::regenerate()
{
	//cout << "robot regen for " << name << " current_hp: " << current_hp << " max_hp: " << max_hp;
    double hp_increase = strength / 6;
    if(hp_increase >= 1)
    {
        current_hp += hp_increase;
        if(current_hp > max_hp)
        {
            current_hp = max_hp;
        }
    }
    else
    {
        current_hp ++;
        if(current_hp > max_hp)
        {
            current_hp = max_hp;
        }
    }
};

/*
 *	useAbility()
 *
 *	Attempts to perform a special ability based on the type of fighter.  The
 *	fighter will attempt to use this special ability just prior to attacking
 *	every turn.
 *
 *	Robot: Shockwave Punch
 *	Adds bonus damage to the Robot's next attack (and only its next attack) equal to (strength  * ((current_energy/maximum_energy)^4)).
 *	Can only be used if the Robot has at least [ROBOT_ABILITY_COST] energy.
 *	Decreases the Robot's current energy by [ROBOT_ABILITY_COST] (after calculating the additional damage) when used.
 *		Examples:
 *		strength=20, current_energy=20, maximum_energy=20		=> bonus_damage=20
 *		strength=20, current_energy=15, maximum_energy=20		=> bonus_damage=6
 *		strength=20, current_energy=10, maximum_energy=20		=> bonus_damage=1
 *		strength=20, current_energy=5,  maximum_energy=20		=> bonus_damage=0
 *	Robot Note:
 *	The bonus damage formula should be computed using double arithmetic, and only
 *	the final result should be cast into an integer.
 *
 *	Return true if the ability was used; false otherwise.
 */
    bool Robot::useAbility()
    {
	if(current_energy >= ROBOT_ABILITY_COST){
		//cout << "SP active for: " << name << " Current energy = " << current_energy << ".  Strength = " << strength << ".  Max energy = " << max_energy << endl;
		double db_strength = double (strength);
		double db_current_energy = double (current_energy);
		double db_max_energy = double (max_energy);
		double db_bonus_damage = db_strength * pow((db_current_energy/db_max_energy), 4.0);
		bonus_damage = db_bonus_damage;
		//cout << "db_strength: " << db_strength << " db_current_energy : " << db_current_energy << " db_max_energy: " << db_max_energy << " bonus damage = " << bonus_damage << endl;
		current_energy = current_energy - ROBOT_ABILITY_COST;
		return true;		
	}
        else{
		bonus_damage = 0;
		return false;
	}
    };



