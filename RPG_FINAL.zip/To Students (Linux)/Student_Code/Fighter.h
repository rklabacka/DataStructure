//
//  Fighter.h
//  Lab_1
//
//  Created by Randy Klabacka on 9/15/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//
#ifndef FIGHTER_H_
#define FIGHTER_H_
#include "FighterInterface.h"

class Fighter:
public FighterInterface
{
public:
    //Fighter Constructor
    Fighter(const std::string name, std::string type, int max_hp, int strength, int speed, int magic);
    //Function override will be needed for cleric and robot
    
    //Accessors
    //getName
    std::string getName();
    //getHP
    int getMaximumHP();
    //getCurrentHP
    int getCurrentHP();
    //getStrength
    int getStrength();
    //getSpeed
    int getSpeed();
    //getMagic
    int getMagic();
    /*
     *	takeDamage(int)
     *
     *	Reduces the fighter's current hit points by an amount equal to the given
     *	damage minus one fourth of the fighter's speed.  This method must reduce
     *	the fighter's current hit points by at least one.  It is acceptable for
     *	this method to give the fighter negative current hit points.
     *
     *	Examples:
     *		damage=10, speed=7		=> damage_taken=9
     *		damage=10, speed=9		=> damage_taken=8
     *		damage=10, speed=50		=> damage_taken=1
     */
    //Damage value should be truncated, not rounded
    void takeDamage(int damage);
    
    /*
     *	regenerate()
     *
     *	Increases the fighter's current hit points by an amount equal to one sixth of
     *	the fighter's strength.  This method must increase the fighter's current hit
     *	points by at least one.  Do not allow the current hit points to exceed the
     *	maximum hit points.
     *
     *	Cleric:
     *	Also increases a Cleric's current mana by an amount equal to one fifth of the
     *	Cleric's magic.  This method must increase the Cleric's current mana by at
     *	least one.  Do not allow the current mana to exceed the maximum mana (again, 5 times its magic).
     */
    //Function override will be used in the parent class
    virtual void regenerate() = 0;
    /*
     * to_string
     *
     */
    std::string to_string() const;
   virtual bool useAbility() = 0; 
    
     
    
protected:
    std::string name;
    std::string type;
    int speed;
    int magic;
    int damage;
    int max_hp;
    int current_hp;
    int strength;
    
    
    
};

#endif
