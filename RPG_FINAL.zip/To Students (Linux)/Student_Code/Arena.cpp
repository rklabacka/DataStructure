//
//  Arena.cpp
//  Lab_1
//
//  Created by Randy Klabacka on 9/21/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//
#include <vector>
#include <sstream>

#include "Arena.h"

/*
 *	addFighter(string)
 *
 *	Adds a new fighter to the collection of fighters in the arena. Do not allow
 *	duplicate names.  Reject any string that does not adhere to the format
 *	outlined in the lab specs.
 *
 *	Return true if a new fighter was added; false otherwise.
 */
bool Arena::addFighter(string fighter_info){
    //initialize variables
    stringstream ss(fighter_info);
    std::string ss_name;
    std::string ss_type;
    int ss_hit_points;
    int ss_strength;
    int ss_speed;
    int ss_magic;
    //create sstream
    
    if(ss >> ss_name){
    for(int i = 0; i < arena_vector.size(); i++){
        if(arena_vector[i]->getName() == ss_name){
            //cout << "Name of fighter already in arena." << endl;
            return false;
        }
	}
    };
    if(ss >> ss_type){
    //ss >> ss_hit_points;
    if(ss >> ss_hit_points && ss_hit_points > 0){
        //ss >> ss_strength;
        if(ss >> ss_strength && ss_strength > 0){
            //ss >> ss_speed;
            if(ss >> ss_speed && ss_speed > 0){
                //ss >> ss_magic;
                if(ss >> ss_magic && ss_magic > 0){
                    if(ss.eof()){
		
			    if(ss_type == "A"){
                	        arena_vector.push_back(new Archer(ss_name, ss_type, ss_hit_points, ss_strength, ss_speed, ss_magic));
                	        return true;
                	    }
                	    else if (ss_type == "R"){
                	        arena_vector.push_back(new Robot(ss_name, ss_type, ss_hit_points, ss_strength, ss_speed, ss_magic));
                	        return true;
                	    }
                	    else if (ss_type == "C"){
                	        arena_vector.push_back(new Cleric(ss_name, ss_type, ss_hit_points, ss_strength, ss_speed, ss_magic));
                	        return true;
                	    }
                	    else{
                	        //cout << "*****ERROR: Object Not Constructed*****" << endl;
                	        return false;
                	    }
                	}
		}
                else{
                    //cout << "ERROR: magic must be > 0" << endl;
                    return false;
                }
            }
            else{
                //cout << "ERROR: speed must be > 0" << endl;
                return false;
            }
        }
        else{
            //cout << "ERROR: strength must be > 0" << endl;
            return false;
        }
    }
    else{
        //cout << "ERROR: maximum hit points must be > 0" << endl;
        return false;
    }
}
};

/*
 *	removeFighter(string)
 *
 *	Removes the fighter whose name is equal to the given name.  Does nothing if
 *	no fighter is found with the given name.
 *
 *	Return true if a fighter is removed; false otherwise.
 */
bool Arena::removeFighter(string name)
{
    int last_position = arena_vector.size() - 1;
    if(arena_vector.size() > 0){
        for(int i = 0; i < arena_vector.size(); i++) {
            if(arena_vector[i]->getName() == name){
                arena_vector[i] = arena_vector[last_position];
                arena_vector.pop_back();
                return true;
            }
        }
    }
    else{
        return false;
    }
    return false;
};


/*
 *	getFighter(string)
 *
 *	Returns the memory address of a fighter whose name is equal to the given
 *	name.  Returns NULL if no fighter is found with the given name.
 *
 *	Return a memory address if a fighter is found; NULL otherwise.
 */
FighterInterface* Arena::getFighter(string name)
    {
        FighterInterface* the_fighter = NULL;
        if(arena_vector.size() > 0){
            for(int i = 0; i < arena_vector.size(); i++)
            {
                if(arena_vector[i]->getName() == name)
                {
                    the_fighter = this->arena_vector[i];
                }
            }
        }
        return the_fighter;
    };

/*
 *	getSize()
 *
 *	Returns the number of fighters in the arena.
 *
 *	Return a non-negative integer.
 */
int Arena::getSize(){
    return arena_vector.size();
};

void Arena::print_vector_names(){
    for(int i = 0; i < arena_vector.size(); i++){
        cout << arena_vector[i]->getName() << endl;
    }
}



