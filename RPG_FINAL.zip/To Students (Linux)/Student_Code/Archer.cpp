//
//  Archer.cpp
//  Lab_1
//
//  Created by Randy Klabacka on 9/15/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#include "Archer.h"

//Archer Constructor is same as Fighter Constructor
Archer::Archer(string name_in, string type_in, int max_hp_in, int strength_in, int speed_in, int magic_in):Fighter(name_in, type_in, max_hp_in, strength_in, speed_in, magic_in)
{
    original_speed = speed_in;
}


/*
 *	getDamage()
 *
 *	Returns the amount of damage a fighter will deal.
 *	Archer:
 *	This value is equal to the Archer's speed.
 */
int Archer::getDamage(){
	//cout << " archer getdamage active for " << name << ". damage(speed) = " << speed;    
	return speed;
}
/*
 *	reset()
 *	Restores a fighter's current hit points to its maximum hit points.
 *	Archer:
 *	Also resets an Archer's current speed to its original value.
 */
void Archer::reset(){
    //cout << " reset for " << name << " prespeed: " << speed;
    current_hp = max_hp;
    speed = original_speed;
    //cout << " postspeed: " << speed;
}

/*
 *	regenerate()
 *
 *	Increases the fighter's current hit points by an amount equal to one sixth of
 *	the fighter's strength.  This method must increase the fighter's current hit
 *	points by at least one.  Do not allow the current hit points to exceed the
 *	maximum hit points.
 *
 */
//Function override will be used in the parent class
void Archer::regenerate()
{
    //cout << " archer regen active for " << name << " prespeed: " << speed;
    double hp_increase = strength / 6;
    if(hp_increase >= 1)
    {
        current_hp += hp_increase;
        if(current_hp > max_hp)
        {
            current_hp = max_hp;
        }
    }
    else
    {
        current_hp ++;
        if(current_hp > max_hp)
        {
            current_hp = max_hp;
        }
    }
	//cout << " postspeed: " << speed;
};
/*
 *	useAbility()
 *
 *	Attempts to perform a special ability based on the type of fighter.  The
 *	fighter will attempt to use this special ability just prior to attacking
 *	every turn.
 *	Archer: Quickstep
 *	Increases the Archer's speed by one point each time the ability is used.
 *	This bonus lasts until the reset() method is used.
 *	This ability always works; there is no maximum bonus speed.
 *	Return true if the ability was used; false otherwise.
 */
bool Archer::useAbility()
    {
        //cout<<" Archer useability active for: " << name << ".  pre-speed: " << speed;
	speed ++;
	//cout << " post-speed: " << speed;
        return true;
    };
