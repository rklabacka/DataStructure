//
//  Archer.h
//  Lab_1
//
//  Created by Randy Klabacka on 9/15/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#ifndef ARCHER_H_
#define ARCHER_H_
#include "Fighter.h"

class Archer:
public Fighter{
public:
//Archer Constructor is same as Fighter Constructor, but still needs to be declareed & implemented
    Archer(std::string name, std::string type, int hp, int strength, int speed, int magic);
/*
 *	getDamage()
 *
 *	Returns the amount of damage a fighter will deal.
 *	Archer:
 *	This value is equal to the Archer's speed.
 */
    int getDamage();
/*
 *	reset()
 *	Restores a fighter's current hit points to its maximum hit points.
 *	Archer:
 *	Also resets an Archer's current speed to its original value.
 */
    void reset();
    
/*
 *	regenerate()
 *
 *	Increases the fighter's current hit points by an amount equal to one sixth of
 *	the fighter's strength.  This method must increase the fighter's current hit
 *	points by at least one.  Do not allow the current hit points to exceed the
 *	maximum hit points.
 *
 */
//Function override will be used in the parent class
    void regenerate();
    
/*
 *	useAbility()
 *
 *	Attempts to perform a special ability based on the type of fighter.  The
 *	fighter will attempt to use this special ability just prior to attacking
 *	every turn.
 *	Archer: Quickstep
 *	Increases the Archer's speed by one point each time the ability is used.
 *	This bonus lasts until the reset() method is used.
 *	This ability always works; there is no maximum bonus speed.
 *	Return true if the ability was used; false otherwise.
 */
    bool useAbility();

private:
    int original_speed;
};

#endif /* defined(__Lab_1__Archer__) */
