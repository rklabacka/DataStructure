//
//  Pathfinder.cpp
//  Lab_5
//
//  Created by Randy Klabacka on 11/3/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#include "Pathfinder.h"

#include <cstdlib>
#include <stack>
#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#include <fstream>
#include <iomanip>
#include <limits>
#include <sstream>
#include <algorithm>
#include <cmath>
#include <stack>

//Constructor
Pathfinder::Pathfinder(){
    srand(time(0));
    current_maze = "empty";
    current_maze = array_to_string();
    for(int z = 0; z < cube_dimensions; z ++){
        for(int y = 0; y < cube_dimensions; y ++){
            for(int x = 0; x < cube_dimensions; x ++){
                array_maze[x][y][z] = 1;
            }
        }
    }

}

//Part 1-----------------------------------------------------------------------------------
/*
 * getMaze
 *
 * Returns a string representation of the current maze. Returns a maze of all 1s if no maze
 * has yet been generated or imported.
 *
 * A valid string representation of a maze consists only of 125 1s and 0s (each separated
 * by spaces) arranged in five 5x5 grids (each separated by newlines). A valid maze must
 * also have 1s in the entrance cell (0, 0, 0) and in the exit cell (4, 4, 4).
 *
 * Cell (0, 0, 0) is represented by the first number in the string representation of the
 * maze. Increasing in x means moving toward the east, meaning cell (1, 0, 0) is the second
 * number. Increasing in y means moving toward the south, meaning cell (0, 1, 0) is the
 * sixth number. Increasing in z means moving downward to a new grid, meaning cell
 * (0, 0, 1) is the twenty-sixth number. Cell (4, 4, 4) is represented by the last number.
 *
 * Returns:		string
 *				A single string representing the current maze
 */
string Pathfinder::getMaze(){
    //cout << "getMaze called: \n" << current_maze << endl;
    //cout << "\narray to string:\n" <<  array_to_string() << endl;
    return current_maze;
}

/*
 * createRandomMaze
 *
 * Generates a random maze and stores it as the current maze.
 *
 * The generated maze must contain a roughly equal number of 1s and 0s and must have a 1
 * in the entrance cell (0, 0, 0) and in the exit cell (4, 4, 4).  The generated maze may be
 * solvable or unsolvable, and this method should be able to produce both kinds of mazes.
 */
void Pathfinder::createRandomMaze(){
    current_maze = "empty";
    for(int z = 0; z < cube_dimensions; z++){
        for(int y = 0; y < cube_dimensions; y++){
            for(int x = 0; x < cube_dimensions; x++){
                if(x == 0 && y == 0 && z == 0){
                    array_maze[x][y][z] = 1;
                }
                else if(x == 4 && y == 4 && z == 4){
                    array_maze[x][y][z] = 1;
                }
                else{
                    int rand_input = rand() % 2;
                    array_maze[x][y][z] = rand_input;
                    //cout << "CHECK: " << array_maze[x][y][z] << endl;
                }
            }
        }
    }
    current_maze = "";
    current_maze = array_to_string();
    //cout << "Here is the current maze (generated from createRandomMaze): \n" << current_maze << endl;
}
//-----------------------------------------------------------------------------------------

//Part 2-----------------------------------------------------------------------------------
/*
 * importMaze
 *
 * Reads in a maze from a file with the given file name and stores it as the current maze.
 * Does nothing if the file does not exist or if the file's data does not represent a valid
 * maze.
 *
 * The file's contents must be of the format described above to be considered valid.
 *
 * Parameter:	file_name
 *				The name of the file containing a maze
 * Returns:		bool
 *				True if the maze is imported correctly; false otherwise
 */
bool Pathfinder::importMaze(string file_name){
    //cout << "importMaze activated for: " << file_name << endl;
    set_copy_to_array();
    string line;
    ifstream in_file;
    in_file.open(file_name);
    int count = 0;
    if(in_file.is_open()){
        for(int z = 0; z < cube_dimensions; z ++){
            if(z > 0){
		if(in_file.eof()){
			break;
		}
                getline(in_file, line);
            }
            for(int y = 0; y < cube_dimensions; y ++){
                getline(in_file, line);
                //cout << "line: " << line << endl;
                istringstream ss(line);
                for(int x = 0; x < cube_dimensions; x ++){
                    string s;
                    ss >> s;
                    //cout << "s for: (" << x << ", " << y << ", " << z << ") = " << s << " ";
                    if(x == 0 && y == 0 && z == 0){
                        if(s != "1"){
                            //cout << "Invalid Import: x, y, & z = 0, value != 1" << endl;
                            set_array_to_copy();
                            return false;
                        }
                        else{
                            //cout << "success for: (" << x << ", " << y << ", " << z << ")" << endl;
                            array_maze[x][y][z] = string_to_int(s);
                            count ++;
                            //cout << "array_maze[" << x << "][" << y << "][" << z << "] = " << array_maze[x][y][z] << endl;
                        }
                    }
                    else if(x == 4 && y == 4 && z == 4){
                        if(s != "1"){
                            //cout << "Invalid Import: x, y, & z = 4, value != 1" << endl;
                            set_array_to_copy();
                            return false;
                        }
                        else{
                            //cout << "success for: (" << x << ", " << y << ", " << z << ")" << endl;
                            array_maze[x][y][z] = string_to_int(s);
                            count ++;
                            //cout << "array_maze[" << x << "][" << y << "][" << z << "] = " << array_maze[x][y][z] << endl;
                        }
                    }
                    else if(s == "1" || s == "0"){
                        //cout << "success for: (" << x << ", " << y << ", " << z << ")" << endl;
                        array_maze[x][y][z] = string_to_int(s);
                        count ++;
                        //cout << "array_maze[" << x << "][" << y << "][" << z << "] = " << array_maze[x][y][z] << endl;
                    }
		    else{
            //cout << "Invalid Import" << endl;
			return false;
		    }
                }
            }
        }
    }
    else{
        //cout << "error: file not open" << endl;
        return false;
    }
    if(getline(in_file, line)){
    set_array_to_copy();
    //cout << "file too large" << endl;
	return false;
    }
    if(count == 125){
    //cout << "import complete: maze valid" << endl;
    current_maze = "";
    array_to_string();
    return true;
    }
    else{
    set_array_to_copy();
    //cout << "invalid import: count off" << endl;
	return false;
    }
}
//-----------------------------------------------------------------------------------------

//Part 3-----------------------------------------------------------------------------------
/*
 * solveMaze
 *
 * Attempts to solve the current maze and returns a solution if one is found.
 *
 * A solution to a maze is a list of coordinates for the path from the entrance to the exit
 * (or an empty vector if no solution is found). This list cannot contain duplicates, and
 * any two consecutive coordinates in the list can only differ by 1 for only one
 * coordinate. The entrance cell (0, 0, 0) and the exit cell (4, 4, 4) should be included
 * in the solution. Each string in the solution vector must be of the format "(x, y, z)",
 * where x, y, and z are the integer coordinates of a cell.
 *
 * Understand that most mazes will contain multiple solutions
 *
 * Returns:		vector<string>
 *				A solution to the current maze, or an empty vector if none exists
 */
vector<string> Pathfinder::solveMaze(){
    path.clear();
    for(int z = 0; z < cube_dimensions; z ++){
	for(int y = 0; y < cube_dimensions; y ++){
	    for(int x = 0; x < cube_dimensions; x ++){
		copy_array[x][y][z] = array_maze[x][y][z];
	    }
	}
    }
    //cout << "solve maze function called" << endl;
    if(discover_path(0, 0, 0)){
    //cout << "inside of solve maze if statement" << endl;
        while(!my_stack.empty()){
            string temp = my_stack.top();
            path.push_back(temp);
        //cout<< temp<< endl;
            my_stack.pop();
        }
    }
    for(int z = 0; z < cube_dimensions; z ++){
	for(int y = 0; y < cube_dimensions; y ++){
	    for(int x =- 0; x < cube_dimensions; x ++){
		copy_array[x][y][z] = array_maze[x][y][z];
	    }
	}
    }
    return path;
}

//check num
bool Pathfinder::check_num(string string_in){
    for(int i = 0; i < string_in.length(); ++ i){
        if(string_in[i] != '1' && string_in[i] != '0'){
            return false;
        }
    }
    return true;
}

string Pathfinder::int_to_string(int int_in){
    stringstream ss;
    string new_str;
    ss << int_in;
    ss >> new_str;
    return new_str;
}

int Pathfinder::string_to_int(string string_in){
    stringstream ss;
    int new_int;
    ss << string_in;
    ss >> new_int;
    return new_int;
}


string Pathfinder::ridSpace(string &str){
    str.erase(std::remove(str.begin(), str.end(), ' '), str.end());
    return str;
}

bool Pathfinder::discover_path(int x, int y, int z){
    if(x == 4 && y == 4 && z == 4){
        my_stack.push("(4, 4, 4)");
        return true;
    }
    else if(x < 0 || x > 4 || y < 0 || y > 4 || z < 0 || z > 4){
        //cout << "fail: (" << x << ", " << y << ", " << z << "): " << copy_array[x][y][z] << ".  Here x, y, or z is either > 4 or < 0" << endl;
        return false;
    }
    else if(copy_array[x][y][z] == 2 || copy_array[x][y][z] == 0){
        //cout << "fail: (" << x << ", " << y << ", " << z << "): " << copy_array[x][y][z] << ".  Here out of bounds or in a place without permission" << endl;
        return false;
    }
    else{
        copy_array[x][y][z] = 2; //visited
    }	
    //cout << "array_maze[" << x << "][" << y << "][" << z << "] = " << copy_array[x][y][z] << ".  ";
    //cout << "(" << x << ", " << y << ", " << z << ") has been changed to 2." << endl;
    if(discover_path(x-1, y, z) || discover_path(x+1, y, z) || discover_path(x, y-1, z) || discover_path(x, y+1, z) || discover_path(x, y, z-1) || discover_path(x, y, z+1)){
        //cout << "recursion if statement worked" << endl;
        string string_x = int_to_string(x);
        string string_y = int_to_string(y);
        string string_z = int_to_string(z);
        my_stack.push("(" + string_x + ", " + string_y + ", " + string_z + ")");
        return true;
    }
    else{
        //cout << "fail: recursion if statement did not work" << endl;
        return false;
    }
}

string Pathfinder::stack_to_string(){
    string return_string = "";
    string temp;
    while(!my_stack.empty()){
        temp = my_stack.top();
        return_string = return_string.append(temp);
        my_stack.pop();
    }
    return return_string;
}

string Pathfinder::array_to_string(){
    if(current_maze != "empty"){
        for(int z = 0; z < cube_dimensions; z ++){
            for(int y = 0; y < cube_dimensions; y ++){
                for(int x = 0; x < cube_dimensions; x ++){
                    if(x == cube_dimensions -1){
                        current_maze.append(int_to_string(array_maze[x][y][z]) + "\n");
                    }
                    else{
                        current_maze.append(int_to_string(array_maze[x][y][z]) + " ");
                    }
                    if(y == cube_dimensions - 1 && x == cube_dimensions - 1){
                        current_maze.append("\n");
                    }
                }
            }
        }
    }
    else{
        current_maze = "";
        for(int z = 0; z < cube_dimensions; z ++){
            for(int y = 0; y < cube_dimensions; y ++){
                for(int x = 0; x < cube_dimensions; x ++){
                    if(x == cube_dimensions -1){
                        current_maze.append(int_to_string(1) + "\n");
                    }
                    else{
                        current_maze.append(int_to_string(1) + " ");
                    }
                    if(y == cube_dimensions - 1 && x == cube_dimensions - 1){
                        current_maze.append("\n");
                    }
                }
            }
        }

    }
    return current_maze;
}

void Pathfinder::test_spot(){
    //cout << "test spot: " << array_maze[1][0][0];
}

void Pathfinder::set_copy_to_array(){
    for(int z = 0; z < cube_dimensions; z ++){
    for(int y = 0; y < cube_dimensions; y ++){
        for(int x = 0; x < cube_dimensions; x ++){
        copy_array[x][y][z] = array_maze[x][y][z];
        }
    }
    }
}

void Pathfinder::set_array_to_copy(){
    for(int z = 0; z < cube_dimensions; z ++){
    for(int y = 0; y < cube_dimensions; y ++){
        for(int x = 0; x < cube_dimensions; x ++){
        array_maze[x][y][z] = copy_array[x][y][z];
        }
    }
    }
}
