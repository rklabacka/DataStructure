//
//  IRDeque.cpp
//  Lab_4
//
//  Created by Randy Klabacka on 10/21/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#include "IRDeque.h"

IRDeque::IRDeque(){
	irdeque_size = 0;
}

bool IRDeque::dup_found(int value){
    if(irdeque.duplicate_found(value)){
        return true;
    }
    else{
        return false;
    }
}

bool IRDeque::add_left(int value){
    if(!irdeque.duplicate_found(value)){
        //cout << "no dupicate found (irdeque.add_left) (IRDeque)" << endl;
        if(irdeque_size < 5){
            irdeque.insertHead(value);
            irdeque_size ++;
            //cout << "irdeque.add_left success (IRDeque)" << endl;
            return true;
        }
        else{
           //cout << "irdeque too big (irdeque.add_left) (IRDeque)" << endl;
            return false;
        }
    }
    else{
        //cout << "irduplicate found (irdeque.add_left) (IRDeque)" << endl;
        return false;
    }
}

void IRDeque::remove_leftest(){
    irdeque.remove(irdeque.at(0));
    irdeque_size --;
    //cout << "irdeque.remove_leftest success (IRDeque)" << endl;
}

void IRDeque::remove_rightest(){
    irdeque.remove(irdeque.at(irdeque_size - 1));
    irdeque_size --;
    //cout << "irdeque.remove_rightest success (IRDeque)" << endl;
}

bool IRDeque::empty(){
	if(irdeque_size <= 0){
		//cout << "irdeque empty" << endl;
		return true;
	}
	else{
		//cout << "irdeque not empty" << endl;
		return false;
	}
}

int IRDeque::get_leftest(){
	return irdeque.at(0);
}

int IRDeque::get_rightest(){
	return irdeque.at(irdeque_size - 1);
}

int IRDeque::size(){
	return irdeque_size;
}

