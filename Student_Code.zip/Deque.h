//
//  Deque.h
//  Lab_4
//
//  Created by Randy Klabacka on 10/21/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_4__Deque__
#define __Lab_4__Deque__

#include <stdio.h>

#include "LinkedList.h"

class Deque{
    
public:
    //constructor
	Deque();

    //check_dup
    bool dup_found(int value);
    
    //add_to_left
    bool add_left(int value);

    //add_to_right
    bool add_right(int value);

    //remove_leftest
    void remove_leftest();

    //remove_rightest
    void remove_rightest();

    //check_if_empty
    bool empty();

    //get_size
    int size();

    //get_leftest
    int get_leftest();

    //get_rightest
    int get_rightest();

private:
    LinkedList<int> deque;
    int deque_size;
};
#endif /* defined(__Lab_4__Deque__) */
