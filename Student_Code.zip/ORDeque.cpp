//
//  ORDeque.cpp
//  Lab_4
//
//  Created by Randy Klabacka on 10/21/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#include "ORDeque.h"


ORDeque::ORDeque(){
	ordeque_size = 0;
}

bool ORDeque::dup_found(int value){
    if(ordeque.duplicate_found(value)){
        return true;
    }
    else{
        return false;
    }
}

bool ORDeque::add_left(int value){
    if(!ordeque.duplicate_found(value)){
        //cout << "no duplicate found (ordeque.add_left) (ORDeque)" << endl;
        if(ordeque_size < 5){
            ordeque.insertHead(value);
            ordeque_size ++;
            //cout << "ordeque.add_left success (ORDeque)" << endl;
            return true;
        }
        else{
            //cout << "ordeque too big (ordeque.add_left) (ORDeque)" << endl;
            return false;
        }
    }
    else{
        //cout << "duplicate found (ordeque.add_left) (ORDeque)" << endl;
        return false;
    }
}

bool ORDeque::add_right(int value){
    if(!ordeque.duplicate_found(value)){
        //cout << "no duplicate found (ordeque.add_left) (ORDeque)" << endl;
        if(ordeque_size < 5){
            ordeque.insertTail(value);
            ordeque_size ++;
            //cout << "ordeque.add_right success (ORDeque)." << value << endl;
            return true;
        }
        else{
            //cout << "ordeque too big (ordeque.add_right) (ORDeque)" << endl;
            return false;
        }
    }
    else{
        //cout << "orduplicate found (ordeque.add_right) (ORDeque)" << endl;
        return false;
    }
}

void ORDeque::remove_leftest(){
    ordeque.remove(ordeque.at(0));
    ordeque_size --;
    //cout << "ordeque.remove_leftest success (ORDeque)" << endl;
}

bool ORDeque::empty(){
	if(ordeque_size <= 0){
		//cout << "ordeque empty" << endl;
		return true;
	}
	else{
		//cout << "ordeque not empty" << endl;
		return false;
	}
}

int ORDeque::get_leftest(){
	return ordeque.at(0);
}

int ORDeque::get_rightest(){
	return ordeque.at(ordeque_size - 1);
}

int ORDeque::size(){
	return ordeque_size;
}
