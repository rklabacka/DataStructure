//
//  Stack.h
//  Lab_4
//
//  Created by Randy Klabacka on 10/21/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_4__Stack__
#define __Lab_4__Stack__

#include <stdio.h>

#include "LinkedList.h"

class Stack{
    
public:
    
    //constructor
    Stack();
    
    //add_to_stack
    bool push(int value);
    
    //remove_from_stack
    void pop();
    
    //check_dup
    bool dup_found(int value);

    //return_top
    int top();

    //check_if_stack_empty
    bool empty();

    //return_stack_size
    int size();


        
private:
    
    LinkedList<int> stack;
    int stack_size;
    
};


#endif /* defined(__Lab_4__Stack__) */
