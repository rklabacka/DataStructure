//
//  Queue.cpp
//  Lab_4
//
//  Created by Randy Klabacka on 10/21/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#include "Queue.h"

Queue::Queue(){
	queue_size = 0;
}

bool Queue::dup_found(int value){
    if(queue.duplicate_found(value)){
        return true;
    }
    else{
        return false;
    }
}

bool Queue::push(int value){
    if(!queue.duplicate_found(value)){
        //cout << "no dupicate found (queue.push)" << endl;
        if(queue_size < 5){
            queue.insertHead(value);
            queue_size ++;
            //cout << "queue.push success" << endl;
            return true;
        }
        else{
            //cout << "queue too big (queue.push)" << endl;
            return false;
        }
    }
    else{
        //cout << "duplicate found (queue.push)" << endl;
        return false;
    }
}

void Queue::pull(){
    queue.remove(queue.at(queue_size - 1));
    queue_size --;
    //cout << "queue.pop success" << endl;
}

int Queue::front(){
	return queue.at(queue_size - 1);
}

int Queue::size(){
	//cout << "queue.size() called.  queue size = " << queue_size << endl;
	return queue_size;
}

bool Queue::empty(){
	if(queue_size <= 0){
		//cout << "queue empty" << endl;
		return true;
	}
	else{
		return false;
	}
}
