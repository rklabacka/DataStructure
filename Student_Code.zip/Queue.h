//
//  Queue.h
//  Lab_4
//
//  Created by Randy Klabacka on 10/21/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_4__Queue__
#define __Lab_4__Queue__

#include <stdio.h>
#include "LinkedList.h"

class Queue{
    
public:
    //constructor
	Queue();

    //check_dup
    bool dup_found(int value);
    
    //add_to_queue
    bool push(int value);

    //remove_item
    void pull();

    //get_front_item
    int front();

    //get_size
    int size();

    //check_if_empty
    bool empty();

private:
    LinkedList<int> queue;
    int queue_size;
    
};


#endif /* defined(__Lab_4__Queue__) */
