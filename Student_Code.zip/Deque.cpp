//
//  Deque.cpp
//  Lab_4
//
//  Created by Randy Klabacka on 10/21/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#include "Deque.h"

Deque::Deque(){
	deque_size = 0;
}

bool Deque::dup_found(int value){
    if(deque.duplicate_found(value)){
        return true;
    }
    else{
        return false;
    }
}

bool Deque::add_left(int value){
    if(!deque.duplicate_found(value)){
        //cout << "no dupicate found (deque.add_left) (Deque)" << endl;
        if(deque_size < 5){
            deque.insertHead(value);
            deque_size ++;
            //cout << "deque.add_left success (Deque)" << endl;
            return true;
        }
        else{
            //cout << "deque too big (deque.add_left) (Deque)" << endl;
            return false;
        }
    }
    else{
        //cout << "duplicate found (deque.add_left) (Deque)" << endl;
        return false;
    }
}

bool Deque::add_right(int value){
    if(!deque.duplicate_found(value)){
        //cout << "no dupicate found (deque.add_left) (Deque)" << endl;
        if(deque_size < 5){
            deque.insertTail(value);
            deque_size ++;
            //cout << "deque.add_right success (Deque)" << endl;
            return true;
        }
        else{
            //cout << "deque too big (deque.add_right) (Deque)" << endl;
            return false;
        }
    }
    else{
        //cout << "duplicate found (deque.add_right) (Deque)" << endl;
        return false;
    }
}

void Deque::remove_leftest(){
    deque.remove(deque.at(0));
    deque_size --;
    //cout << "deque.remove_leftest success (Deque)" << endl;
}

void Deque::remove_rightest(){
    deque.remove(deque.at(deque_size - 1));
    deque_size --;
    //cout << "deque.remove_rightest success (Deque)" << endl;
}

bool Deque::empty(){
	if(deque_size <= 0){
		//cout << "deque empty" << endl;
		return true;
	}
	else{
		//cout << "deque not empty" << endl;
		return false;
	}
}

int Deque::get_leftest(){
	return deque.at(0);
}

int Deque::get_rightest(){
	return deque.at(deque_size - 1);
}

int Deque::size(){
	return deque_size;
}
