//
//  Stack.cpp
//  Lab_4
//
//  Created by Randy Klabacka on 10/21/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#include "Stack.h"
#include "Station.h"

Stack::Stack(){
    stack_size = 0;
}

bool Stack::push(int value){
    if(!stack.duplicate_found(value)){
        //cout << "no dupicate found (stack.push)" << endl;
        if(stack_size < 5){
            stack.insertHead(value);
            stack_size ++;
            //cout << "stack.push success" << endl;
            return true;
        }
        else{
            //cout << "stack too big (stack.push)" << endl;
            return false;
        }
    }
    else{
        //cout << "duplicate found (stack.push)" << endl;
        return false;
    }
}

void Stack::pop(){
    stack.remove(stack.at(0));
    stack_size --;
    //cout << "stack.pop success" << endl;
}

bool Stack::empty(){
	if(stack_size > 0){
		//cout << "stack not empty" << endl;
		return false;
	}
	else{
		//cout << "stack empty" << endl;
		return true;
	}
}

int Stack::top(){
	//cout << "stack top function called" << endl;
	return stack.at(0);
}

bool Stack::dup_found(int value){
    if(stack.duplicate_found(value)){
        return true;
    }
    else{
        return false;
    }
}

int Stack::size(){
	//cout << "stack.size() called.  stack size = " << stack_size << endl;
	return stack_size;
}

