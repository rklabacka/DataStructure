//
//  Student.cpp
//  Lab_7
//
//  Created by Randy Klabacka on 11/30/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#include <iomanip>
#include <iostream>
#include <sstream>

#include "Student.h"

//constructor
Student::Student(unsigned long long int ID_in, string name_in, string address_in, string phone_in){
    stu_ID = ID_in;
    stu_name = name_in;
    stu_address = address_in;
    stu_phone = phone_in;
    course_count = 0;
    running_grade = 0;
    stu_GPA = "0.00";
}


/*
 * getID()
 *
 * Returns the ID of the Student.
 */
unsigned long long int Student::getID(){
    return stu_ID;
}

/*
 * getName()
 *
 * Returns the name of the Student
 */

string Student::getName(){
    return stu_name;
}

/*
 * getGPA()
 *
 * Returns the string representation of the Student's GPA.
 */

string Student::getGPA(){
    return stu_GPA;
}

/*
 * addGPA()
 *
 * Incorporates the given course grade into the Student's overall GPA.
 */

void Student::addGPA(double classGrade){
	//cout << "addGPA function entered for: " << stu_name << endl;
    running_grade += classGrade;
    course_count ++;
    //cout << "running_grade = " << stu_int_to_string(running_grade) << " course_count = " << stu_int_to_string(course_count) << endl;
    double precise_GPA;
    if(course_count != 0 && running_grade != 0){
    	precise_GPA = running_grade / course_count;
    }
    else{
    	precise_GPA = 0.00;
    }
    stringstream ss;
    ss << fixed << setprecision(2);
    ss << precise_GPA;
    stu_GPA = ss.str();
    //cout << "new GPA = " << stu_GPA << endl << endl;

}

/*
 * toString()
 *
 * The student object will be put into string representation. Student info will be
 * ordered ID, name, address, phone number, and GPA. Each piece of information will
 * be on its own line. GPA will not have a newline following it and the precision
 * of the GPA will be rounded to two decimal places. For example,
 *
 * 123456789
 * Ben Thompson
 * 17 Russell St, Provo, UT 84606
 * 555-555-5555
 * 3.12
 *
 * Returns a string representation of the student object There is no trailing new line.
 */
string Student::toString(){
    string string_ID;
    stringstream ss;
    ss << stu_ID;
    ss >> string_ID;
    string return_string = string_ID + "\n" + stu_name + "\n" + stu_address + "\n" + stu_phone + "\n" + stu_GPA;
    return return_string;
}

//int to string
string Student::stu_int_to_string(int value_in){
    string value_out; stringstream ss;
    ss << value_in; ss >> value_out;
    return value_out;
}
