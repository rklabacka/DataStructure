//
//  GPA.cpp
//  Lab_7
//
//  Created by Randy Klabacka on 11/30/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//
#include <fstream>
#include <string>
#include <stdio.h>
#include <iostream>
#include <sstream>
#include <map>
#include <set>

#include "GPA.h"

using namespace std;

//constructor
GPA::GPA(){}

//destructor
GPA::~GPA(){
	clear();
}

/*
 * getMap()
 *
 * Returns the map storing the student information.
 * The key of the map should be the student ID.
 */
map<unsigned long long int,StudentInterface*> GPA::getMap(){
    return my_map;
}

/*
 * getSet()
 *
 * Returns the set storing the student information.
 */
set<StudentInterface*,Comparator> GPA::getSet(){
    return my_set;
}

/*
 * importStudents()
 *
 * Read in and parse through the given files. Each part of an entry in a
 * file is given on a separate line in the file. Student ID is first, name is
 * second, address is third, and phone is last. There are no blank lines between
 * students. The following is an example file:
 *
 *	 5291738600
 * 	 Dick B. Smith
 * 	 879 Maple Road, Centralia, Colorado 24222
 * 	 312-000-1000
 * 	 9251738707
 *	 Harry C. Anderson
 *	 635 Main Drive, Midville, California 48444
 * 	 660-050-2200
 *
 * If a valid file is given, the new Students should be added to the existing
 * map and set.
 *
 * If an invalid file name is given or if there is a missing entry for a student,
 * return false. Duplicate student ID numbers and duplicate students will not be
 * tested for. There will never be a student that exists in the map and set. If
 * the function returns false, then no changes should have been made to the
 * existing map or set.
 *
 * The key of the map should be the student ID.
 *
 * Returns false if an invalid filename is given or if there is a missing entry for a
 * student, otherwise true.
 */
bool GPA::importStudents(string mapFileName, string setFileName){
    //cout << "importStudents function entered for: " << mapFileName << " & " << setFileName << endl;
    if(validity_check(mapFileName) && validity_check(setFileName)){
        cout << "files both valid" << endl;
        fstream fsmap;
        unsigned long long int map_file_ID;
        string map_file_name;
        string map_file_address;
        string map_file_phone;
        string nothing;
        fsmap.open(mapFileName);
        int map_count = 1;
        while(fsmap >> map_file_ID){
        	//cout << "map_ID" << map_count << ": " << ID_to_string(map_file_ID) << endl;
        	getline(fsmap, nothing);
            if(getline(fsmap, map_file_name)){
            	//cout << "map_file_name" << map_count << ": " << map_file_name << endl;
                if(getline(fsmap, map_file_address)){
                	//cout << "map_file_address" << map_count << ": " << map_file_address << endl;
                    if(getline(fsmap, map_file_phone)){
                    	//cout << "map_file_phone" << map_count << ": " << map_file_phone << endl << endl;
                        //is a student!
                        StudentInterface* map_ptr = new Student(map_file_ID, map_file_name, map_file_address, map_file_phone);
                        my_map[map_file_ID] = map_ptr;
                    }
                }
            }
        	map_count ++;
        }
        fstream fsset;
        unsigned long long int set_file_ID;
        string set_file_name;
        string set_file_address;
        string set_file_phone;
        fsset.open(setFileName);
        int set_count = 1;
        while(fsset >> set_file_ID){
        	//cout << "set_ID" << set_count << ": " << ID_to_string(set_file_ID) << endl;
        	if(set_count > 0){
        		if(getline(fsset, nothing)){
        			//cout << "gotem'" << endl;
        	    }
        	}
            if(getline(fsset, set_file_name)){
            	//cout << "set_file_name" << set_count << ": " << set_file_name << endl;
                if(getline(fsset, set_file_address)){
                	//cout << "set_file_address" << set_count << ": " << set_file_address << endl;
                    if(getline(fsset, set_file_phone)){
                    	//cout << "set_file_phone" << set_count << ": " << set_file_phone << endl << endl;
                        //is a student!
                        StudentInterface* set_ptr = new Student(set_file_ID, set_file_name, set_file_address, set_file_phone);
                        my_set.insert(set_ptr);
                    }
                }
            }
            set_count ++;
        }
        return true;
    }

    else{
        //cout << "files invalid" << endl;
        return false;}
}

//set.insert(ptr)

/*
 * importGrades()
 *
 * Read in and parse through the given file. Each part of an entry in the file
 * is given on a separate line in the file. Student ID is first, course is
 * second, and grade is last. There are no blank lines between entries. The
 * following is an example file:
 *
 * 	5291738860
 * 	CHEM134
 * 	A
 * 	9251734870
 * 	BOT180
 * 	B
 * 	9251733870
 * 	PE273
 * 	D+
 * 	5291738760
 * 	HIS431
 *  	A-
 *
 * Compute the GPA by finding the average of all the grades with a matching student ID
 * in the Grade file. The GPA is calculated by taking a Student's total sum GPA and
 * dividing by the number of classes taken. If the given student ID has no matching
 * grades in the Grade file, the GPA is 0.00. It is not necessary to store the course
 * names so long as the total number of courses taken is counted.
 *
 * You may assume that the given student ID exists in the map or set.
 *
 * Use the following point values for each grade.
 *
 *		  A = 4.0  A- = 3.7
 *	B+ = 3.4  B = 3.0  B- = 2.7
 *	C+ = 2.4  C = 2.0  C- = 1.7
 *	D+ = 1.4  D = 1.0  D- = 0.7
 *		  E = 0.0
 *
 * Returns false if an invalid filename is given, otherwise true.
 */
bool GPA::importGrades(string fileName){
	//cout << "importGrades function entered for: " << fileName << endl;
    if (validity_check_GPA(fileName)){
    	//cout << "importGrades validity check confirmed" << endl;
        fstream fsGPA;
        unsigned long long int GPA_file_ID;
        string course_grade;
        string nothing;
        fsGPA.open(fileName);
        int grade_count = 1;
        while(fsGPA >> GPA_file_ID){
        	//cout << "GPA_file_ID" << grade_count << ": " << ID_to_string(GPA_file_ID) << endl;
            if(getline(fsGPA, nothing)){
            	getline(fsGPA, nothing);
                if(getline(fsGPA, course_grade)){
                	//cout << "course_grade" << grade_count << ": " << course_grade << endl;
                    double grade_value = GPA_converter(course_grade);
                    if(my_map.count(GPA_file_ID) == 0){
                    	//cout << "addGPA to be done for setID " << ID_to_string(GPA_file_ID) << " where course_grade = " << course_grade << endl;
                        //do set stuff
                        for(auto set_ptr:my_set){
                            if(set_ptr->getID() == GPA_file_ID){
                                set_ptr->addGPA(grade_value);
                                break;
                            }
                        }
                    }
                    else{
                    	//cout << "addGPA to be done for mapID " << ID_to_string(GPA_file_ID) << " where course_grade = " << course_grade << endl;
                        my_map[GPA_file_ID]->addGPA(grade_value);
                    }
                }
            }
            grade_count ++;
        }
        return true;
    }
    else{
        //cout << "Failed validity_check_GPA" << endl;
        return false;
    }
}

/*
 * querySet()
 *
 * Read in and parse through the given file. The 'Query' file contains a list of
 * student ID numbers. Each entry in the Query file is a student ID given on a
 * line by itself. You are to compute and report the GPA for each of the students
 * listed in the Query file. The following is an example Query file:
 *
 * 	5291738860
 * 	9251733870
 *
 * For each student ID given in the Query file, use the student information stored in
 * your set to compute the GPA for the student and create an output string which
 * contains the student ID, GPA, and name. If the given student ID does not match any
 * student, do not give any output for that student ID. Each line of the output string
 * contains student ID, GPA, and name as shown:
 *
 * 	5291738860 2.85 Dick B. Smith
 *	9251733870 3.00 Harry C. Anderson
 *
 * Return a string representation of the given query. If an invalid file name is given,
 * then return an empty string. The precision of the GPA will be rounded to two decimal places.
 * There will be a trailing new line.
 */
string GPA::querySet(string fileName){
	//cout << "querySet function entered" << endl;
    fstream fsQuerySet;
    string return_string = "";
    unsigned long long int QS_file_ID;
    fsQuerySet.open(fileName);
    int query_set_count = 1;
    while(fsQuerySet >> QS_file_ID){
    	//cout << "QS_file_ID" << query_set_count << " : " << ID_to_string(QS_file_ID) << endl;
        for(auto set_ptr:my_set){
            if(set_ptr->getID() == QS_file_ID){
                return_string.append(ID_to_string(QS_file_ID) + " " + set_ptr->getGPA() + " " + set_ptr->getName() + "\n");
            }
        }
    }
    return return_string;
}

/*
 * queryMap()
 *
 * Read in and parse through the given file. The 'Query' file contains a list of
 * student ID numbers. Each entry in the Query file is a student ID given on a
 * line by itself. You are to compute and report the GPA for each of the students
 * listed in the Query file. The following is an example Query file:
 *
 * 	5291738860
 * 	9251733870
 *
 * For each student ID given in the Query file, use the student information stored in
 * your map to compute the GPA for the student and create an output string which
 * contains the student ID, GPA, and name. If the given student ID does not match any
 * student, do not give any output for that student ID. Each line of the output string
 * contains student ID, GPA, and name as shown:
 *
 * 	5291738860 2.85 Dick B. Smith
 *	9251733870 3.00 Harry C. Anderson
 *
 * Return a string representation of the given query. if an ivalid file name is given,
 * then return an empty string. The precision of the GPA will be rounded to two decimal places.
 * There will be a trailing new line.
 */
string GPA::queryMap(string fileName){
	//cout << "queryMap function entered" << endl;
    fstream fsQueryMap;
    string return_string = "";
    unsigned long long int QM_file_ID;
    fsQueryMap.open(fileName);
    while(fsQueryMap >> QM_file_ID){
        StudentInterface* map_ptr = my_map[QM_file_ID];
        if(map_ptr != NULL){
            return_string.append(ID_to_string(QM_file_ID) + " " + map_ptr->getGPA() + " " + map_ptr->getName() + "\n");
        }
    }
    return return_string;
}

/*
 * Clears the students from the map and set.
 */
void GPA::clear(){
	for(StudentInterface* set_ptr:my_set){
		delete set_ptr;
	}
	for(pair<unsigned long long int, StudentInterface*> map_ptr:my_map){
		delete map_ptr.second;
	}
    my_map.clear();
    my_set.clear();
}

//Check file validity
bool GPA::validity_check(string file_name){
    fstream fs;
    int line_count = 0;
    string line;
    ifstream myfile(file_name);
    while (getline(myfile, line))
        ++line_count;
    if(line_count == 0){
    	return false;
    }
    else if(line_count%4 != 0){
        return false;
    }
    else{
        return true;
    }
}

//Check GPA file validity
bool GPA::validity_check_GPA(string file_name){
    fstream fs;
    int line_count = 0;
    string line;
    ifstream myfile(file_name);
    while (getline(myfile, line))
        ++line_count;
    if(line_count == 0){
    	return false;
    }
    else if(line_count%3 != 0){
        return false;
    }
    else{
        return true;
    }
}

/*GPA converter
 * Use the following point values for each grade.
 *
 *		  A = 4.0  A- = 3.7
 *	B+ = 3.4  B = 3.0  B- = 2.7
 *	C+ = 2.4  C = 2.0  C- = 1.7
 *	D+ = 1.4  D = 1.0  D- = 0.7
 *		  E = 0.0
*/
double GPA::GPA_converter(string course_grade){
	//cout << "GPA converter entered" << endl;
    double grade_value;
    if(course_grade == "A"){
        grade_value = 4.0;
    }
    else if(course_grade == "A-"){
        grade_value = 3.7;
    }
    else if(course_grade == "B+"){
        grade_value = 3.4;
    }
    else if(course_grade == "B"){
        grade_value = 3.0;
    }
    else if(course_grade == "B-"){
        grade_value = 2.7;
    }
    else if(course_grade == "C+"){
        grade_value = 2.4;
    }
    else if(course_grade == "C"){
        grade_value = 2.0;
    }
    else if(course_grade == "C-"){
        grade_value = 1.7;
    }
    else if(course_grade == "D+"){
        grade_value = 1.4;
    }
    else if(course_grade == "D"){
        grade_value = 1.0;
    }
    else if(course_grade == "D-"){
        grade_value = 0.7;
    }
    else if(course_grade == "E"){
        grade_value = 0.0;
    }
    else{
        //cout << "error with GPA_converter" << endl;
        grade_value = 9999.99;
    }
    return grade_value;
}

//ID to string
string GPA::ID_to_string(unsigned long long int ID_in){
    string ID_out; stringstream ss;
    ss << ID_in; ss >> ID_out;
    return ID_out;
}

//int to string
string GPA::int_to_string(int value_in){
    string value_out; stringstream ss;
    ss << value_in; ss >> value_out;
    return value_out;
}

//map check
void GPA::map_check(unsigned long long int value){
    StudentInterface* ptr = my_map[value];
    string string_ID = ID_to_string(value);
    if(ptr != NULL){
        //cout << "searched ID " << string_ID << " yields name: " << ptr->getName() << endl;
    }
    else{
        //cout << "searched ID " << string_ID << " yields no name" << endl;
    }
}

