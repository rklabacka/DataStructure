//
//  Student.h
//  Lab_7
//
//  Created by Randy Klabacka on 11/30/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_7__Student__
#define __Lab_7__Student__

#include <stdio.h>
#include <set>
#include <map>
#include <algorithm>
#include <iterator>
#include <string>

#include "StudentInterface.h"

class Student:
public StudentInterface{

public:
    
//constructor
    Student(unsigned long long int stu_ID, string stu_name, string stu_address, string stu_phone);
    
    //destructor
~Student(){};

/*
 * getID()
 *
 * Returns the ID of the Student.
 */
    unsigned long long int getID();

/*
 * getName()
 *
 * Returns the name of the Student
 */

string getName();

/*
 * getGPA()
 *
 * Returns the string representation of the Student's GPA.
 */

string getGPA();

/*
 * addGPA()
 *
 * Incorporates the given course grade into the Student's overall GPA.
 */

void addGPA(double classGrade);

/*
 * toString()
 *
 * The student object will be put into string representation. Student info will be
 * ordered ID, name, address, phone number, and GPA. Each piece of information will
 * be on its own line. GPA will not have a newline following it and the precision
 * of the GPA will be rounded to two decimal places. For example,
 *
 * 123456789
 * Ben Thompson
 * 17 Russell St, Provo, UT 84606
 * 555-555-5555
 * 3.12
 *
 * Returns a string representation of the student object There is no trailing new line.
 */
string toString();

//int to string
string stu_int_to_string(int value_in);
    
private:
    unsigned long long int stu_ID;
    string stu_name;
    string stu_GPA;
    double running_grade;
    double course_count;
    string stu_address;
    string stu_phone;

};

#endif /* defined(__Lab_7__Student__) */
