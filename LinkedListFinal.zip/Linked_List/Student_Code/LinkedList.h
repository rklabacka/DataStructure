//
//  LinkedList.h
//  Lab_2
//
//  Created by Randy Klabacka on 10/5/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#ifndef LINKEDLIST_H_
#define LINKEDLIST_H_
#include "LinkedListInterface.h"
#include <string>
#include <stdexcept>
#include <iostream>

using namespace std;

template <typename T>
class LinkedList:public LinkedListInterface<T>{
public:
    //CONSTRUCTOR
    LinkedList(){
        head = NULL;
        list_size = 0;
    }
    //DESTRUCTOR
    ~LinkedList(){
        clear();
    }
    
    //MEMBER FUNCTIONS
    
    /*insertHead (node insert at beginning)
     Make sure to check for duplicates
     */
    void insertHead(T value){
	int duplicates = 0;
        if(list_size > 0){
            Node* iterator = head;
            //Check for duplicates
            for(int i = 0; i <= list_size - 1; i ++){
                if(iterator->data != value){
                    iterator = iterator->next;
                }
                else{
		    duplicates = 1;
                    break;
                }
            }
	    if(duplicates != 1){
            	head = new Node(value, head);
	    	list_size ++;
	    }
           // cout << "head inserted: " << value << endl;
        }
        else if(list_size == 0){
            head = new Node(value);
           // cout << "head inserted: " << value << endl;
	    list_size ++;
        }
    }
    /*insertTail (node insert and end)
     Make sure to check for duplicates
     */
    void insertTail(T value){
        if(list_size > 0){
            Node* iterator = head;
            //Check for duplicates
	    int count = 0;
            while(iterator->next != NULL){
                if(iterator->data != value){
                    iterator = iterator->next;
		    count ++;
//		    cout << "Iterator increase: " << count << endl;
                }
                else{
//		    cout << "broke: duplicate found" << endl;
                    break;
                }
            }
	    if(iterator->data != value){
            	iterator->next = new Node(value);
	    	list_size ++;
//           	cout << "tail inserted: " << value << endl;
	    }
	    else{
//		cout << "broke: duplicate found at last node" << endl;
 	    }
        }
        else if(list_size == 0){
            head = new Node(value);
//            cout << "tail inserted: " << value << endl;
	    list_size ++;
        }
    }
    /*insertAfter (node insert after insertionNode)
     Make sure insertionNode is in the list.  If not, do not insert.
     Make sure to check for duplicates
     */
    void insertAfter(T value, T insertionNode){
	int duplicates = 0;
        //Search list for duplicates
        if(list_size > 0){
            Node* iterator1 = head;
            while(iterator1 != NULL){
//		cout << "inside insertAfter's duplicate loop" << endl;
                if(iterator1->data != value){
                    iterator1 = iterator1->next;
                }
                else{
		    duplicates = 1;
                    break;
                }
            }
        }
	if(duplicates != 1){
            //Create temporary pointer to hold new node
            Node* temp = NULL;
            //Use iterator to find node to insert after (insertionNode)
            Node* iterator2 = head;
            while(iterator2 != NULL){
//		cout << "inside insertAfter's insert loop" << endl;
                if(iterator2->data == insertionNode)
                {
		    temp = iterator2->next;
		    iterator2->next = new Node(value);
		    iterator2->next->next = temp;
		    list_size ++;
		    break;   
                }
		iterator2 = iterator2->next;
            }
	}
    }
    /*remove (remove node of given value)
     Node may or may not be part of the list
     */
    void remove(T value){
	if(head != NULL){
        Node* iterator1 = head->next;
	Node* iterator2 = head;
	if(iterator2->data == value){
		head = head->next;
		delete iterator2;
		list_size --;
	}
	else{	
	    while(iterator1 != NULL){
		if(iterator1->data == value){
			iterator2->next = iterator1->next;
			delete iterator1;
			list_size --;
			break;
		}
		else{
			iterator1 = iterator1->next;
			iterator2 = iterator2->next;
		}
	    }
	}
    }
    }
    /*clear (remove all nodes from list)
     */
    void clear(){
	if(head != NULL){
        Node* iterator = head;
	while(iterator != NULL){
		head = head->next;
		delete iterator;
		iterator = head;
		list_size --;
	}
	head = NULL;
	}
	//content
        list_size = 0;
    }
    /*at (return value of node at given index (index should be >= 0)
     If index is out of range, throw an out of range exception
     */
    T at(int index){
        Node* iterator = head;
	int count = 0;
	if(index < 0 || index > list_size - 1){
		throw out_of_range("OUT OF RANGE");
	}
	else if(index >= 0){
	while(iterator != NULL){
		if(count  == index){
			return iterator->data;
			break;
		}
		else{
			iterator = iterator->next;
			count ++;
        	}
	}
	}
    }
    
    int size(){
        return list_size;
    }
    //To String Function
    void to_string(){
        Node* iter = head;
        int count = 0;
        while(iter != NULL){
            cout << "item " << count << ": " << iter->data << endl;
            iter = iter->next;
            count ++;
        }
    }
    
    
private:
    //NODE STRUCT
    struct Node{
	Node(T data_in, Node* next_in){
		data = data_in;
		next = next_in;
	}
    Node(T data_in){
        data = data_in;
        next = NULL;
    }
    T data;
    Node* next;
};
    
    //DATA MEMBERS
    Node* head;
    int list_size;
};


#endif
