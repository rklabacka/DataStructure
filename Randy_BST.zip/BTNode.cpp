//
//  BTNode.cpp
//  Lab_6
//
//  Created by Randy Klabacka on 11/16/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#include "BTNode.h"

#include <stdio.h>
#include <ostream>
#include <string>
#include <sstream>

using namespace std;


/*
 * Returns the data that is stored in this node
 *
 * @return the data that is stored in this node.
 */

int BTNode::getData(){
    return data;
}

/*
 * Returns the left child of this node or null if it doesn't have one.
 *
 * @return the left child of this node or null if it doesn't have one.
 */
NodeInterface* BTNode::getLeftChild(){
    return left;
}

/*
 * Returns the right child of this node or null if it doesn't have one.
 *
 * @return the right child of this node or null if it doesn't have one.
 */
NodeInterface* BTNode::getRightChild(){
    return right;
}