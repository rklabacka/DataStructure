//CREATE BINARY TREE CLASS (CLASS DEFINITION):

//See page 459
#ifndef BINARY_TREE_H
#define BINARY_TREE_H
/** Class for a binary tree. */
#include <cstddef>
#include <sstream>
#include <stdexcept>
#include <string>

#include "BSTInterface.h"
#include "NodeInterface.h"
#include "BTNode.h"


class BST:
public BSTInterface
{
    //-----------------------------------------------------------------------------------------------
public:
    
    BST();
    ~BST();
    
    //FROM BSTInterface:
    //Please note that the class that implements this interface must be made
    //of objects which implement the NodeInterface
    
    /*
     * Returns the root node for this tree
     *
     * @return the root node for this tree.
     */
    NodeInterface* getRootNode();
    
    /*
     * Attempts to add the given int to the BST tree
     *
     * @return true if added
     * @return false if unsuccessful (i.e. the int is already in tree)
     */
    bool add(int data);
    
    //recursion_add (help session)
    bool recur_add(BTNode*& curr, int to_add);
    
    /*
     * Attempts to remove the given int from the BST tree
     *
     * @return true if successfully removed
     * @return false if remove is unsuccessful(i.e. the int is not in the tree)
     */
    bool remove(int data);
    
    //recursion_remove (help session)
    bool recur_rem(BTNode*& curr, int to_remove);
    
    //removing the in order predecessor
    bool rem_iop(BTNode*& to_remove, BTNode*& iop);
    
    /*
     * Removes all nodes from the tree, resulting in an empty tree.
     */
    void clear();
    
    //-----------------------------------------------------------------------------------------------

    

private:
    
    //Initialize root
    BTNode* root;

};


#endif
