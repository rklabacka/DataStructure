//
//  BST.cpp
//  Lab_6
//
//  Created by Randy Klabacka on 11/16/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#include "BST.h"

//CONSTRUCTOR
BST::BST(){
    root = NULL;
}

BST::~BST(){}

//FROM BSTInterface:

//Please note that the class that implements this interface must be made
//of objects which implement the NodeInterface

/*
 * Returns the root node for this tree
 *
 * @return the root node for this tree.
 */
NodeInterface* BST::getRootNode(){
    return root;
}

/*
 * Attempts to add the given int to the BST tree
 *
 * @return true if added
 * @return false if unsuccessful (i.e. the int is already in tree)
 */
bool BST::add(int data){
    //cout << "add function entered" << endl;
    if(recur_add(root, data)){
        return true;
    }
    else{
        return false;
    }
}

//RECUR_ADD

bool BST::recur_add(BTNode* &curr, int to_add){
    if(curr == NULL){
        curr = new BTNode(to_add);
        return true;
    }
    else if(to_add < curr->data){
        return recur_add(curr->left, to_add);
    }
    else if(to_add > curr->data){
        return recur_add(curr->right, to_add);
    }
    else if(to_add == curr->data){
        //cout << "duplicate found in recur_add function" << endl;
        return false;
    }
    else{
        //cout << "unknown error: thompsoni" << endl;
        return false;
    }
}


/*
 * Attempts to remove the given int from the BST tree
 *
 * @return true if successfully removed
 * @return false if remove is unsuccessful(i.e. the int is not in the tree)
 */
bool BST::remove(int data){
    //cout << "remove function entered" << endl;
    return recur_rem(root, data);
}

//RECUR_REM
bool BST::recur_rem(BTNode*& curr, int to_remove){
    if(curr == NULL){
        //cout << "unknown error: tuberculosus" << endl;
        return false;
    }
    else if(to_remove == curr->data){
        if(curr->left == NULL && curr->right == NULL){
        	//cout << "to_remove data identified as " << curr->data << ", and has successfully been removed" << endl;
        	BTNode* temp = curr;
            curr = NULL;
            delete temp;
            return true;
        }
        else if(curr->left != NULL && curr->right != NULL){
            //In order predecessor (IOP)
            return rem_iop(curr, curr->left);
        }
        else if(curr->left != NULL){
            BTNode* temp = curr;
            curr = curr->left;
            delete temp;
            return true;
        }
        else if(curr->right != NULL){
            BTNode* temp = curr;
            curr = curr->right;
            delete temp;
            return true;
        }
        else{
            //cout << "unknown error: xanti" << endl;
            return false;
        }
    }
    else if(to_remove < curr->data){
        return recur_rem(curr->left, to_remove);
    }
    else if(to_remove > curr->data){
        return recur_rem(curr->right, to_remove);
    }
    else{
        //cout << "unknown error: reissi" << endl;
        return false;
    }
}

//REM_IOP
bool BST::rem_iop(BTNode*& to_remove, BTNode*& iop){
    if(iop->right != NULL){
        return rem_iop(to_remove, iop->right);
    }
    else{
        to_remove->data = iop->data;
        return recur_rem(iop, iop->data);
    }
}

/*
 * Removes all nodes from the tree, resulting in an empty tree.
 */
void BST::clear(){
    while(root != NULL){
        remove(root->data);
    }
}




