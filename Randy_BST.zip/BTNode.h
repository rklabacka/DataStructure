//
//  BTNode.h
//  Lab_6
//
//  Created by Randy Klabacka on 11/16/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_6__BTNode__
#define __Lab_6__BTNode__

#include "NodeInterface.h"

#include <stdio.h>
#include <ostream>
#include <string>
#include <sstream>

/** A node for a Binary Tree. */
struct BTNode:
public NodeInterface
{
public:
    // Constructor
    BTNode(const int the_data, BTNode* left_val = NULL, BTNode* right_val = NULL) :
    data(the_data), left(left_val),  right(right_val) {}
    // Destructor (to avoid warning message)
    ~BTNode() {}
    
    int getData();
    
    /*
     * Returns the left child of this node or null if it doesn't have one.
     *
     * @return the left child of this node or null if it doesn't have one.
     */
    NodeInterface* getLeftChild();
    
    /*
     * Returns the right child of this node or null if it doesn't have one.
     *
     * @return the right child of this node or null if it doesn't have one.
     */
    NodeInterface* getRightChild();
    
    // Data Fields
    int data;
    BTNode* left;
    BTNode* right;
}; // End BTNode


#endif /* defined(__Lab_6__BTNode__) */
