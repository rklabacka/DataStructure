//
//  QS.cpp
//  Lab_8
//
//  Created by Randy Klabacka on 12/3/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#include "QS.h"

#include <algorithm>
#include <sstream>
#include <string>

using namespace std;

//Constructor
QS::QS(){
    array_ptr = NULL;
    current_size = 0;
    max_capacity = 0;
}

//Destructor
QS::~QS(){ clear(); }

/*
 * sortAll()
 *
 * Sorts elements of the array.  After this function is called, every
 * element in the array is less than or equal its successor.
 *
 * Does nothing if the array is empty.
 */
void QS::sortAll(){
    if(current_size == 0){
        return;
    }
    quicksort(0, current_size - 1);
}

//quicksort
void QS::quicksort(int left, int right){
    if(right - left < 2){
        return;
    }
    int piv = medianOfThree(left, right);
    piv = partition(left, right, piv);
    quicksort(left, piv - 1);
    quicksort(piv + 1, right);
}

/*
 * medianOfThree()
 *
 * The median of three pivot selection has two parts:
 *
 * 1) Calculates the middle index by averaging the given left and right indices:
 *
 * middle = (left + right)/2
 *
 * 2) Then bubble-sorts the values at the left, middle, and right indices.
 *
 * After this method is called, data[left] <= data[middle] <= data[right].
 * The middle index will be returned.
 *
 * Returns -1 if the array is empty, if either of the given integers
 * is out of bounds, or if the left index is not less than the right
 * index.
 *
 * @param left
 * 		the left boundary for the subarray from which to find a pivot
 * @param right
 * 		the right boundary for the subarray from which to find a pivot
 * @return
 *		the index of the pivot (middle index); -1 if provided with invalid input
 */
int QS::medianOfThree(int left, int right){
	//cout << "MedianOfThree entered for " << int_to_string(left) << " and " << int_to_string(right);
    if(not_valid(left, right)){
    	//cout << " medianOfThree failed." << endl;
        return -1;
    }
    int mid = (left + right) / 2;
    med_3_swap(left, mid);
    med_3_swap(mid, right);
    med_3_swap(left, mid);
    //cout << " mid determined to be: " << int_to_string(mid) << endl;
    //cout << "values after medianOftThree: left= " << int_to_string(array_ptr[left]) << " middle = " << int_to_string(array_ptr[mid]) << " right = " << int_to_string(array_ptr[right]) << endl;
    return mid;
}

//med_3_swap (bubble swap)
void QS::med_3_swap(int val_left, int val_right){
    if(array_ptr[val_right] < array_ptr[val_left]){
        int temp = array_ptr[val_left];
        array_ptr[val_left] = array_ptr[val_right];
        array_ptr[val_right] = temp;
    }
}

/*
 * Partitions a subarray around a pivot value selected according to
 * median-of-three pivot selection.
 *
 * The values which are smaller than the pivot should be placed to the left
 * of the pivot; the values which are larger than the pivot should be placed
 * to the right of the pivot.
 *
 * Returns -1 if the array is null, if either of the given integers is out of
 * bounds, or if the first integer is not less than the second integer, or if the
 * pivot is not between the two boundaries.
 *
 * @param left
 * 		the left boundary for the subarray to partition
 * @param right
 * 		the right boundary for the subarray to partition
 * @param pivotIndex
 * 		the index of the pivot in the subarray
 * @return
 *		the pivot's ending index after the partition completes; -1 if
 * 		provided with bad input
 */
int QS::partition(int left, int right, int pivotIndex){
	//cout << "partition entered for: " << getArray() << endl << "left = " << int_to_string(left) << " right = " << int_to_string(right) << " pivotIndex = " << int_to_string(pivotIndex) << endl;
    if(not_valid(left, right) || pivotIndex < left || pivotIndex > right){
    	//cout << "array not valid" << endl;
        return -1;
    }
    if(left == pivotIndex || right == pivotIndex){
    	if(left == pivotIndex){ swap_values(left, pivotIndex); return left;}
    	else if(right == pivotIndex){ swap_values(pivotIndex, right); return right;}
    }
    int piv = array_ptr[pivotIndex];
    swap_values(left, pivotIndex);
    int moves_up = left + 1;
    int moves_down = right;
    while(moves_up < moves_down){
        while(array_ptr[moves_up] <= piv){
            if(moves_up + 1 != max_capacity){ moves_up ++; }
            else{ break; }
        }
        while(array_ptr[moves_down] > piv){
        	 if(moves_down - 1 >= 0){ moves_down --; }
        	 else{ break; }
        }
        if(moves_up < moves_down){
            swap_values(moves_up, moves_down);
        }
    }
    swap_values(left, moves_down);
    return moves_down;
}

//swap
void QS::swap_values(int left, int right){
    int temp = array_ptr[left];
    array_ptr[left] = array_ptr[right];
    array_ptr[right] = temp;
}

/*
 * Produces a comma delimited string representation of the array. For example: if my array
 * looked like {5,7,2,9,0}, then the string to be returned would look like "5,7,2,9,0"
 * with no trailing comma.  The number of cells included equals the number of values added.
 * Do not include the entire array if the array has yet to be filled.
 *
 * Returns an empty string, if the array is NULL or empty.
 *
 * @return
 *		the string representation of the current array
 */
string QS::getArray(){
    string return_string = "";
    if(array_ptr == NULL){ return return_string; }
    for(int i = 0; i < current_size - 1; i++){
        stringstream ss;
        ss << array_ptr[i];
        return_string.append(ss.str() + ",");
    }
    stringstream ss;
    ss << array_ptr[current_size - 1];
    return_string.append(ss.str());
    return return_string;
}

/*
 * Returns the number of elements which have been added to the array.
 */
int QS::getSize(){
    return current_size;
}

/*
 * Adds the given value to the end of the array starting at index 0.
 * For example, the first time addToArray is called,
 * the give value should be found at index 0.
 * 2nd time, value should be found at index 1.
 * 3rd, index 2, etc up to its max capacity.
 *
 * If the array is filled, do nothing.
 */
void QS::addToArray(int value){
    if(current_size < max_capacity){
        array_ptr[current_size] = value;
        current_size ++;
    }
}

/*
 * Dynamically allocates an array with the given capacity.
 * If a previous array had been allocated, delete the previous array.
 * Returns false if the given capacity is non-positive, true otherwise.
 *
 * @param
 *		size of array
 * @return
 *		true if the array was created, false otherwise
 */
bool QS::createArray(int capacity){
    if(capacity < 0){ return false; }
    if(array_ptr != NULL){ clear(); }
    array_ptr = new int[capacity];
    max_capacity = capacity;
    return true;
}
    
/*Returns -1 if the array is empty, if either of the given integers
* is out of bounds, or if the left index is not less than the right
* index.
*/
//verify
bool QS::not_valid(int left, int right){
    if(current_size == 0 || left < 0 || right > max_capacity - 1 || left >= right ){
        return true;
    }
    return false;
}

/*
 * Resets the array to an empty or NULL state.
 */
void QS::clear(){
    if(array_ptr != NULL){ delete[] array_ptr; array_ptr = NULL; current_size = 0; }
}

string QS::int_to_string(int value){
	stringstream ss;
	ss << value;
	return ss.str();
}
