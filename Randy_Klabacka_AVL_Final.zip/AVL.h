//
//  AVL.h
//  AVL_Lab
//
//  Created by Randy Klabacka on 12/7/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#ifndef __AVL_Lab__AVL__
#define __AVL_Lab__AVL__

#include <cstddef>
#include <sstream>
#include <stdexcept>
#include <string>

#include "AVLInterface.h"
#include "NodeInterface.h"
#include "BTNode.h"


class AVL:
public AVLInterface
{
    //-----------------------------------------------------------------------------------------------
public:
    
    AVL();
    ~AVL();
    
    //FROM BSTInterface:
    //Please note that the class that implements this interface must be made
    //of objects which implement the NodeInterface
    
    /*
     * Returns the root node for this tree
     *
     * @return the root node for this tree.
     */
    NodeInterface* getRootNode();
    
    /*
     * Attempts to add the given int to the BST tree
     *
     * @return true if added
     * @return false if unsuccessful (i.e. the int is already in tree)
     */
    bool add(int data);
    
    //recursion_add (help session)
    bool recur_add(BTNode*& curr, int to_add);
    
    /*
     * Attempts to remove the given int from the BST tree
     *
     * @return true if successfully removed
     * @return false if remove is unsuccessful(i.e. the int is not in the tree)
     */
    bool remove(int data);
    
    //recursion_remove (help session)
    bool recur_rem(BTNode*& curr, int to_remove);
    
    //removing the in order predecessor
    bool rem_iop(BTNode*& to_remove, BTNode*& iop);
    
    /*
     * Removes all nodes from the tree, resulting in an empty tree.
     */
    void clear();
    
    //-----------------------------------------------------------------------------------------------
    
    int get_height(BTNode* local_root);
    
    /*rebalance_left
        LEFT-LEFT heavy tree: single right rotation around parent
        LEFT-RIGHT heavy tree: (1) rotate left around child (2) rotate right around parent
     Best algorithm for this:
     if( the left subtree has a positive balance (LEFT-RIGHT heavy){
        rotate left around the left subtree root
     }
     Rotate right around local root   */
    void rebalance_left(BTNode*& local_root);
    
    /*rebalance_right
     RIGHT-RIGHT heavy tree: single left rotation around parent
     RIGHT-LEFT heavy tree: (1) rotate right around child (2) rotate left around parent
     Best algorithm for this:
     if( the right subtree has a negative balance (RIGHT-LEFT heavy){
     rotate right around the left subtree root
     }
     Rotate left around local root   */
    void rebalance_right(BTNode*& local_root);
    
    /** rotate_right
     pre: local_root is the root of a binary search tree
     post: local_root->left is the root of a binary search tree
     local_root->left->left is raised one level
     local_root->left->right does not change levels
     local_root->right is lowered one level
     local_root is set to the new root
     @param local_root The root of the binary tree to be rotated
     */
    void rotate_right(BTNode*& local_root);

    void rotate_left(BTNode*& local_root);
    
    // Public Member Functions
    /** Insert an item into the tree.
     post: The item is in the tree.
     @param item The item to be inserted
     @return true only if the item was not
     already in the tree
     */
    bool insert(BTNode item);

    
    /** Remove an item from the tree.
     post: The item is no longer in the tree.
     @param item The item to be removed
     @return true only if the item was in the tree
     */
    bool erase(const int& item);


    
private:
    
    //Initialize root
    BTNode* root;
    bool increase = false;
    bool decrease = false;
    
};


#endif /* defined(__AVL_Lab__AVL__) */
