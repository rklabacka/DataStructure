//
//  BTNode.h
//  AVL_Lab
//
//  Created by Randy Klabacka on 12/7/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#ifndef __AVL_Lab__BTNode__
#define __AVL_Lab__BTNode__

#include "NodeInterface.h"

#include <stdio.h>
#include <ostream>
#include <string>
#include <sstream>

/** A node for a Binary Tree. */
struct BTNode:
public NodeInterface
{
public:
    // Constructor
    BTNode(const int the_data, BTNode* left_val = NULL, BTNode* right_val = NULL) :
    data(the_data), left(left_val),  right(right_val), height(1) {}
    // Destructor (to avoid warning message)
    ~BTNode() {}
    
    int getData();
    
    /*
     * Returns the left child of this node or null if it doesn't have one.
     *
     * @return the left child of this node or null if it doesn't have one.
     */
    NodeInterface* getLeftChild();
    
    /*
     * Returns the right child of this node or null if it doesn't have one.
     *
     * @return the right child of this node or null if it doesn't have one.
     */
    NodeInterface* getRightChild();
    
    /*
     * Returns the height of this node. The height is the number of nodes
     * along the longest path from this node to a leaf.  While a conventional
     * interface only gives information on the functionality of a class and does
     * not comment on how a class should be implemented, this function has been
     * provided to point you in the right direction for your solution.  For an
     * example on height, see page 448 of the text book.
     *
     * @return the height of this tree with this node as the local root.
     */
    int getHeight();
    
    //to_string
    string to_string();
    
    //get_balance
    int get_balance();
    
    // Data Fields
    int data;
    BTNode* left;
    BTNode* right;
    int height = 1;
}; // End BTNode

#endif /* defined(__AVL_Lab__BTNode__) */
