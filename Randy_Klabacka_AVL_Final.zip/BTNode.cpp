//
//  AVLNode.cpp
//  AVL_Lab
//
//  Created by Randy Klabacka on 12/7/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#include "BTNode.h"

#include <stdio.h>
#include <ostream>
#include <string>
#include <sstream>

using namespace std;


/*
 * Returns the data that is stored in this node
 *
 * @return the data that is stored in this node.
 */

int BTNode::getData(){
    return data;
}

/*
 * Returns the left child of this node or null if it doesn't have one.
 *
 * @return the left child of this node or null if it doesn't have one.
 */
NodeInterface* BTNode::getLeftChild(){
    return left;
}

/*
 * Returns the right child of this node or null if it doesn't have one.
 *
 * @return the right child of this node or null if it doesn't have one.
 */
NodeInterface* BTNode::getRightChild(){
    return right;
}

/*
 * Returns the height of this node. The height is the number of nodes
 * along the longest path from this node to a leaf.  While a conventional
 * interface only gives information on the functionality of a class and does
 * not comment on how a class should be implemented, this function has been
 * provided to point you in the right direction for your solution.  For an
 * example on height, see page 448 of the text book.
 *
 * @return the height of this tree with this node as the local root.
 */
int BTNode::getHeight(){
    return height;
}

//get_balance
int BTNode::get_balance(){
    if(right == NULL && left == NULL){
        return 0;
    }
    else if(right == NULL && left != NULL){
        return -1;
    }
    else if(right != NULL && left == NULL){
        return 1;
    }
    else{
        return 999;
    }
    
}

//to_string
string BTNode::to_string(){
    stringstream ss;
    ss << data;
    string return_string = ("data: " + ss.str() + " ");
    return return_string;
}
