//
//  AVL.cpp
//  AVL_Lab
//
//  Created by Randy Klabacka on 12/7/15.
//  Copyright (c) 2015 Randy Klabacka. All rights reserved.
//

#include "AVL.h"

#include <string>
#include <iostream>

using namespace std;

//CONSTRUCTOR
AVL::AVL(){
    root = NULL;
}

AVL::~AVL(){clear();}

//FROM BSTInterface:

//Please note that the class that implements this interface must be made
//of objects which implement the NodeInterface

/*
 * Returns the root node for this tree
 *
 * @return the root node for this tree.
 */
NodeInterface* AVL::getRootNode(){
    return root;
}

/*
 * Attempts to add the given int to the AVL tree
 *
 * @return true if added
 * @return false if unsuccessful (i.e. the int is already in tree)
 */
bool AVL::add(int data){
    //if(data == -8) { cout << "HHHEEEEEYYYY!!!!!! add function entered for -8" << endl; }
    //cout << "add function entered" << endl;
    if(recur_add(root, data)){
        return true;
    }
    else{
        return false;
    }
}

//RECUR_ADD

bool AVL::recur_add(BTNode*& curr, int to_add){
    if(curr == NULL){ //if_1
        curr = new BTNode(to_add);
        increase = true;
        return true;
    }
    else if(to_add < curr->data){ //else if_1

        bool return_value = recur_add(curr->left, to_add);
        if(increase){ //if_2
            int balance = get_height(curr->right) - get_height(curr->left);

            if(balance < -1){ //if_3

                rebalance_left(curr);
                increase = false;
            }
            else if(balance > 1){ //else if_2

                rebalance_right(curr);
                increase = false;
            }
        }
        return return_value;
    }
    else if(to_add > curr->data){ //else if_3
        bool return_value = recur_add(curr->right, to_add);
        if(increase){ //if_3
            int balance = get_height(curr->right) - get_height(curr->left);
            if(balance < -1){ //if_4
                rebalance_left(curr);
                increase = false;
            }
            else if(balance > 1){ //else if_4
                rebalance_right(curr);
                increase = false;
            }
        }
        return return_value;
    }
    else if(to_add == curr->data){
        return false;
    }
    else{
        return false;
    }
}


/*
 * Attempts to remove the given int from the BST tree
 *
 * @return true if successfully removed
 * @return false if remove is unsuccessful(i.e. the int is not in the tree)
 */
bool AVL::remove(int data){
	//if( data <= 50 && data >= 40){ cout << "GET RID OF " << data << "!!" << endl; }
    return recur_rem(root, data);
}

//RECUR_REM
bool AVL::recur_rem(BTNode*& curr, int to_remove){
	//cout << "in recur_rem for " << to_remove << endl;
    if(curr == NULL){
        return false;
    }
    else if(to_remove == curr->data){
    	//cout << "you found " << to_remove << " within the remove function." << endl;
        if(curr->left == NULL && curr->right == NULL){
            BTNode* temp = curr;
            curr = NULL;
            //cout << "delete of " << temp->data << " success" << endl;
            delete temp;
            decrease = true;
            return true;
        }
        else if(curr->left != NULL && curr->right != NULL){
            //In order predecessor (IOP)
            decrease = true;
            bool return_value = rem_iop(curr, curr->left);
            if(decrease){ //if_2
               int balance = get_height(curr->right) - get_height(curr->left);
               if(balance < -1){ //if_3
                    rebalance_left(curr);
                    //decrease = false;
               }
               else if(balance > 1){ //else if_2
                    rebalance_right(curr);
                    //decrease = false;
               }
            }
            return return_value;
        }
        else if(curr->left != NULL){
            BTNode* temp = curr;
            curr = curr->left;
            //cout << "delete of " << temp->data << " success" << endl;
            delete temp;
            decrease = true;
            return true;
        }
        else if(curr->right != NULL){
            BTNode* temp = curr;
            curr = curr->right;
            //cout << "delete of " << temp->data << " success" << endl;
            delete temp;
            decrease = true;
            return true;
        }
        else{
        	//cout << "ERROR: remove fail" << endl;
            return false;
        }
    }
    else if(to_remove < curr->data){ //Here I simply copied and pasted and then made modifications from the recur_add function
        bool return_value = recur_rem(curr->left, to_remove);
        if(decrease){ //if_2
            int balance = get_height(curr->right) - get_height(curr->left);
            if(balance < -1){ //if_3
                rebalance_left(curr);
                //decrease = false;
            }
            else if(balance > 1){ //else if_2
                rebalance_right(curr);
                //decrease = false;
            }
        }
        return return_value;
    }
    else if(to_remove > curr->data){
    	 bool return_value = recur_rem(curr->right, to_remove);
    	        if(decrease){ //if_2
    	            int balance = get_height(curr->right) - get_height(curr->left);
    	            if(balance < -1){ //if_3
    	                rebalance_left(curr);
    	                //decrease = false;
    	            }
    	            else if(balance > 1){ //else if_2
    	                rebalance_right(curr);
    	                //decrease = false;
    	            }
    	        }
    	        return return_value;
    }
    else{
        return false;
    }
}

//REM_IOP
bool AVL::rem_iop(BTNode*& to_remove, BTNode*& iop){
	//cout << "rem_iop activated. to_remove = " << to_remove->data << endl;
    if(iop->right != NULL){
        bool return_value = rem_iop(to_remove, iop->right);
        if(decrease){
        	int balance = get_height(iop->right) - get_height(iop->left);
        	if(balance < -1){ //if_3
        	    rebalance_left(iop);
        	    //decrease = false;
        	}
        	else if(balance > 1){ //else if_2
        	    rebalance_right(iop);
        	    //decrease = false;
        	}
        }
        return return_value;
    }
    else{
    	to_remove->data = iop->data;
    	decrease = true;
    	return recur_rem(iop, iop->data);
   }
}

/*
 * Removes all nodes from the tree, resulting in an empty tree.
 */
void AVL::clear(){
    while(root != NULL){
        remove(root->data);
    }
}

/*---------------------------------------------------------------------------------------------------------------------*/

int AVL::get_height(BTNode* local_root){
    if(local_root == NULL){ //if_1
        //cout << "get_height worked for NULL (if_1) ! height = 0" << endl;
        return 0;
    }
    //cout << "get_height entered for " << local_root->data << endl;
    int rc_height = 0;
    int lc_height = 0;
    if(local_root->right != NULL){ //if_2
        //cout << "get_height if_2 entered for" << local_root->data << endl;
        rc_height = 1 + get_height(local_root->right);
    }
    if(local_root->left != NULL){ //if_3
        //cout << "get_height if_3 entered for" << local_root->data << endl;
        lc_height = 1 + get_height(local_root->left);
    }
    if(local_root->right == NULL && local_root->left == NULL){ //if_4
        //cout << "get_height worked for " << local_root->data << " (if_4) ! height = " << local_root->height << endl;
        return local_root->height;
    }
    if(rc_height > lc_height){ //if_5
        //cout << "get_height worked for " << local_root->data << " (rc) (if_5) ! height = " << rc_height << endl;
        return rc_height;
    }
    else{ //else
        //cout << "get_height worked for " << local_root->data << " (lc) (else) ! height = " << rc_height << endl;
        return lc_height;
    }
}

/*rebalance_left
 LEFT-LEFT heavy tree: single right rotation around parent
 LEFT-RIGHT heavy tree: (1) rotate left around child (2) rotate right around parent
 Best algorithm for this:
 if( the left subtree has a positive balance (LEFT-RIGHT heavy){
 rotate left around the left subtree root
 }
 Rotate right around local root   */
void AVL::rebalance_left(BTNode*& local_root){
    //cout << "rebalance_left entered for " << local_root->data << endl;
    bool LEFT_RIGHT;
    //find out if left-left or left-right
    int left_balance = get_height(local_root->left->right) - get_height(local_root->left->left);
    //if balance < 0, it's left-left
    if(left_balance < 0){ //it's a left-left tree
    	//cout << "LEFT-LEFT tree for: " << local_root->data << endl;
        LEFT_RIGHT = false;}
    else if(left_balance > 0){ //it's a left-right tree
    	//cout << "LEFT-RIGHT tree for: " << local_root->data << endl;
        LEFT_RIGHT = true;}
    else{ LEFT_RIGHT = false; /*cout << "**ERROR** rebalance_left entered and the left subtree has a balance of 0" << endl;*/ }
    if(LEFT_RIGHT){
        rotate_left(local_root->left); }
    rotate_right(local_root);
    
}

/*rebalance_right
 RIGHT-RIGHT heavy tree: single left rotation around parent
 RIGHT-LEFT heavy tree: (1) rotate right around child (2) rotate left around parent
 Best algorithm for this:
 if( the right subtree has a negative balance (RIGHT-LEFT heavy){
 rotate right around the left subtree root
 }
 Rotate left around local root   */
void AVL::rebalance_right(BTNode*& local_root){
    //cout << "rebalance_right entered for " << local_root->data << endl;
    bool RIGHT_LEFT;
    //find out if right-right or right-left
    int right_balance = get_height(local_root->right->right) - get_height(local_root->right->left);
    //if balance < 0, it's right-left
    if(right_balance < 0){ //it's a right-left tree
    	//cout << "RIGHT-LEFT tree for: " << local_root->data << endl;
        RIGHT_LEFT = true;}
    else if(right_balance > 0){ //it's a right-right tree
    	//cout << "RIGHT-RIGHT tree for: " << local_root->data << endl;
        RIGHT_LEFT = false;}
    else{ RIGHT_LEFT = false; /*cout << "**ERROR** rebalance_right entered and the right subtree has a balance of 0" << endl;*/ }
    if(RIGHT_LEFT){
        rotate_right(local_root->right); }
    rotate_left(local_root);
    
}




/** rotate_right
 pre: local_root is the root of a binary search tree
 post: local_root->left is the root of a binary search tree
 local_root->left->left is raised one level
 local_root->left->right does not change levels
 local_root->right is lowered one level
 local_root is set to the new root
 @param local_root The root of the binary tree to be rotated
 */
void AVL::rotate_right(BTNode*& local_root){
    //cout << "rotate_left entered for " << local_root->data << endl;
    BTNode* temp = local_root->left;
    local_root->left = temp->right;
    temp->right = local_root;
    local_root = temp;
}

/** rotate_left
 pre: local_root is the root of a binary search tree
 post: local_root->left is the root of a binary search tree
 local_root->left->left is raised one level
 local_root->left->right does not change levels
 local_root->right is lowered one level
 local_root is set to the new root
 @param local_root The root of the binary tree to be rotated
 */

//*******I just did the reciprocal of rotate_right, so make sure this is right!*******
void AVL::rotate_left(BTNode*& local_root){
    //cout << "rotate_left entered for " << local_root->data << endl;
    BTNode* temp = local_root->right;
    local_root->right = temp->left;
    temp->left = local_root;
    local_root = temp;
}

//insert
bool insert(BTNode item);

